/**
 * Vercel Serverless Function Entry Point
 * 
 * Self-contained API handler. All /api/* routes are defined in this file.
 * Does NOT load any external server file (no dist/server).
 * Webhook: /webhook/webhook -> api/whatsapp-webhook.js (see vercel.json).
 */

import 'dotenv/config';
import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs';
import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { sql } from 'drizzle-orm';
import { generateToken, verifyToken, extractToken } from './utils/jwt.js';
import {
  calcBudgetPercent,
  calcBurnRate,
  calcInventoryTotal,
  findFirstExpenseDate,
  normalizeCategory,
  sumByCategory,
  sumExpenses,
  isNonDeleted,
  dateKey,
} from '../shared/calculations.js';
import {
  formatCurrency,
  formatDate,
  formatDaysRemaining,
  formatProjectionDate,
} from '../shared/formatting.js';

/** Linked WhatsApp profile IDs + auth user id — mirrors GET /api/projects. */
async function getLinkedUserIdsForAuth(supabase, userId) {
  const ids = new Set([userId]);
  const { data: linked } = await supabase.from('profiles').select('id').eq('auth_user_id', userId);
  if (linked && Array.isArray(linked)) {
    for (const p of linked) {
      if (p?.id) ids.add(p.id);
    }
  }
  return [...ids];
}

/**
 * Unified weekly burn-rate calculation.
 * Handles single-day and sparse data gracefully:
 *   - If all expenses span < 4 days → use (totalSpent / unique spending days) * 7
 *   - Otherwise → use (totalSpent / days elapsed since first expense) * 7
 * expenses must be an array of objects with .expense_date or .created_at fields.
 */
function computeWeeklyBurnRate(expenses, totalSpent) {
  if (!expenses || expenses.length === 0 || totalSpent <= 0) return 0;

  const dates = expenses
    .map((e) => {
      const d = (e.expense_date || e.created_at || '').toString().split('T')[0];
      return d ? new Date(d + 'T12:00:00').getTime() : null;
    })
    .filter(Boolean);

  if (dates.length === 0) return 0;

  const firstMs = Math.min(...dates);
  const lastMs = Math.max(...dates);
  const spannedDays = Math.max(1, (lastMs - firstMs) / 86400000);
  const daysSinceFirst = Math.max(1, (Date.now() - firstMs) / 86400000);

  const uniqueDates = new Set(
    expenses
      .map((e) => (e.expense_date || e.created_at || '').toString().split('T')[0])
      .filter(Boolean)
  );
  const daysWithSpending = Math.max(1, uniqueDates.size);

  if (spannedDays < 4) {
    // Too early: project only has a few days of history.
    // Use per-active-day average × 7 to give a realistic weekly extrapolation.
    return Math.round((totalSpent / daysWithSpending) * 7);
  }

  // Normal case: enough history — use days elapsed since first expense.
  return Math.round((totalSpent / daysSinceFirst) * 7);
}

/** True if user owns the project (directly or via linked profile) or is manager_id. */
async function userHasProjectAccess(supabase, projectId, userId) {
  const allowed = await getLinkedUserIdsForAuth(supabase, userId);
  const { data: projectRow } = await supabase
    .from('projects')
    .select('id, user_id, manager_id')
    .eq('id', projectId)
    .maybeSingle();
  if (!projectRow) return false;
  if (allowed.includes(projectRow.user_id)) return true;
  if (projectRow.manager_id && projectRow.manager_id === userId) return true;
  return false;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// ─── Photo URL Normalizer ────────────────────────────────────────────────────
// The daily_logs.photo_urls column can store three formats due to mixed writes:
//   1. Plain URL string:          "https://..."
//   2. Object:                    { url: "https://...", caption: null, tag: null }
//   3. JSON-stringified object:   '{"url":"https://...","caption":null,"tag":null}'
// This helper always returns a { url, caption, tag } object regardless of input format.
function normalizePhotoEntry(e) {
  if (typeof e === 'string') {
    const t = e.trim();
    if (t.startsWith('{') || t.startsWith('"')) {
      try {
        const parsed = JSON.parse(t);
        if (parsed && typeof parsed === 'object' && parsed.url) {
          return { url: parsed.url, caption: parsed.caption ?? null, tag: parsed.tag ?? null };
        }
      } catch { /* not JSON — fall through */ }
    }
    return t.startsWith('http') ? { url: t, caption: null, tag: null } : null;
  }
  if (e && typeof e === 'object' && e.url) {
    return { url: e.url, caption: e.caption ?? null, tag: e.tag ?? null };
  }
  return null;
}

function normalizePhotoUrls(raw) {
  const arr = Array.isArray(raw) ? raw : raw ? [raw] : [];
  return arr.map(normalizePhotoEntry).filter(Boolean);
}

// Create Express app
const app = express();

// ============================================================================
// MIDDLEWARE
// ============================================================================

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// CORS - allow credentials for same-origin; JWT sent via Authorization header
app.use((req, res, next) => {
  const origin = req.headers.origin || 'https://build-monitor-lac.vercel.app';
  res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, Accept');
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  next();
});

// Trust proxy for Vercel
app.set('trust proxy', 1);

// Request logging (no session — we use JWT only)
app.use((req, res, next) => {
  if (req.path.startsWith('/api')) {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  }
  if (req.path.startsWith('/webhook')) {
    console.log(`[Request] ${req.method} ${req.path} - ${req.url}`);
  }
  next();
});

// ============================================================================
// DATABASE CONNECTION (Direct connection for serverless)
// ============================================================================

// Initialize database connection directly (for use in api/index.js)
// This avoids needing to import from dist/server/db.js which isn't available
let db = null;
let dbInitialized = false;

function initializeDatabase() {
  if (dbInitialized) return db;
  
  try {
    if (!process.env.DATABASE_URL) {
      console.warn('⚠️ DATABASE_URL not set - database features will be unavailable');
      dbInitialized = true;
      return null;
    }

    const queryClient = postgres(process.env.DATABASE_URL, {
      max: 10,
      idle_timeout: 20,
      connect_timeout: 10,
    });

    // Initialize Drizzle with minimal schema (we'll use raw SQL for testing)
    db = drizzle(queryClient);
    dbInitialized = true;
    console.log('✅ Database connection initialized');
    return db;
  } catch (error) {
    console.error('❌ Failed to initialize database:', error);
    dbInitialized = true;
    return null;
  }
}

// ============================================================================
// HEALTH CHECK
// ============================================================================

app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'production'
  });
});

// ============================================================================
// WEBHOOK ROUTES
// ============================================================================
// Twilio WhatsApp webhook — handle inside index so we never 404 when rewrite hits index
app.all('/api/whatsapp-webhook', async (req, res) => {
  try {
    const { default: webhookHandler } = await import('./whatsapp-webhook.js');
    return webhookHandler(req, res);
  } catch (err) {
    console.error('[Webhook] Error:', err);
    res.setHeader('Content-Type', 'text/xml');
    return res.status(200).send(
      '<?xml version="1.0" encoding="UTF-8"?><Response></Response>'
    );
  }
});

// ============================================================================
// API ROUTES (all handlers are defined below — no external server file)
// ============================================================================

// Explicit route for dashboard summary — use Supabase so dashboard sees same data as WhatsApp webhook
app.get('/api/projects/:projectId/summary', (req, res, next) => {
  requireAuth(req, res, async () => {
    const projectId = req.params.projectId;
    const userId = req.userId || req.user?.id;
    if (!userId) {
      return res.status(401).json({ success: false, error: 'Not authenticated' });
    }
    try {
      console.log('[Summary] Running query for:', { projectId, userId });

      let projectRow = null;
      let totalSpent = 0;
      let expenseRowsForCumulative = [];
      let materialsRows = [];
      let openIssuesCount = 0;
      let criticalIssuesCount = 0;
      let totalTasksCount = 0;
      let completedTasksCount = 0;

      // Prefer Supabase client so we read the SAME database the WhatsApp webhook writes to
      const supabaseUrl = process.env.SUPABASE_URL;
      const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
      if (supabaseUrl && supabaseServiceKey) {
        const { createClient } = await import('@supabase/supabase-js');
        const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

        const allowedSummary = await userHasProjectAccess(supabase, projectId, userId);
        if (!allowedSummary) {
          return res.status(404).json({ success: false, error: 'Project not found' });
        }
        const { data: projectData, error: projectError } = await supabase
          .from('projects')
          .select('id, name, budget, currency, status, created_at')
          .eq('id', projectId)
          .maybeSingle();
        if (projectError || !projectData) {
          console.error('[Summary] Supabase project error:', projectError);
          return res.status(404).json({ success: false, error: projectError?.message || 'Project not found' });
        }
        projectRow = projectData;

        let expenseRowCount = 0;
        // DO NOT redeclare `expenseRowsForCumulative` with `let` here — the
        // outer binding at the top of this handler holds the rows every
        // downstream derivation (firstExpenseDate, calcBurnRate,
        // sumByCategory, cumulativeCosts) reads from. A block-scoped shadow
        // previously lived here and silently zeroed the summary payload:
        // totalSpent worked (outer scope) but categoryTotals / burn /
        // firstExpenseDate all read `[]`. See Debug Panel diff 2026-04-20.
        if (projectRow) {
          const { data: expenseRows, error: expenseError } = await supabase
            .from('expenses')
            .select('id, amount, expense_date, created_at, category, deleted_at')
            .eq('project_id', projectId)
            .is('deleted_at', null);
          if (expenseError) console.error('[Summary] Supabase expenses error:', expenseError);
          expenseRowCount = (expenseRows || []).length;
          // Use shared sumExpenses() for float-safe (integer-cents) arithmetic.
          totalSpent = sumExpenses(expenseRows || []);
          expenseRowsForCumulative = expenseRows || [];
        }

        if (projectRow) {
          const { data: materialsData, error: materialsError } = await supabase
            .from('materials_inventory')
            .select('id, name, quantity, unit, unit_cost, low_stock_threshold')
            .eq('project_id', projectId);
          if (materialsError) console.error('[Summary] Supabase materials_inventory error:', materialsError);
          materialsRows = materialsData || [];
        }

        try {
          const { count: openCount } = await supabase
            .from('issues')
            .select('*', { count: 'exact', head: true })
            .eq('project_id', projectId)
            .eq('status', 'open');
          const { count: criticalCount } = await supabase
            .from('issues')
            .select('*', { count: 'exact', head: true })
            .eq('project_id', projectId)
            .eq('status', 'open')
            .in('severity', ['high', 'critical']);
          openIssuesCount = openCount ?? 0;
          criticalIssuesCount = criticalCount ?? 0;
        } catch (issueErr) {
          console.warn('[Summary] Issues count failed:', issueErr?.message);
          openIssuesCount = 0;
          criticalIssuesCount = 0;
        }

        // Task-based progress: completed tasks ÷ total tasks.
        //
        // This is the ONLY honest progress number the system can produce today.
        // We previously returned a hardcoded 0, and earlier than that returned
        // `min(100, spent/budget)` which conflated money with schedule and
        // misled owners whose projects were "67% done" purely because they
        // had overspent. Until phases/milestones land, task completion is the
        // correct proxy.
        //
        // Soft-deleted tasks are excluded so cancelled work can't game the
        // percentage. Tasks with status 'done' are treated as completed
        // alongside 'completed' because the WhatsApp agent writes either.
        try {
          const { count: totalCount } = await supabase
            .from('tasks')
            .select('*', { count: 'exact', head: true })
            .eq('project_id', projectId)
            .is('deleted_at', null);
          const { count: doneCount } = await supabase
            .from('tasks')
            .select('*', { count: 'exact', head: true })
            .eq('project_id', projectId)
            .is('deleted_at', null)
            .in('status', ['completed', 'done']);
          totalTasksCount = totalCount ?? 0;
          completedTasksCount = doneCount ?? 0;
        } catch (taskErr) {
          console.warn('[Summary] Tasks count failed:', taskErr?.message);
          totalTasksCount = 0;
          completedTasksCount = 0;
        }

        console.log('[Summary Debug]', {
          projectId,
          source: 'supabase',
          projectFound: !!projectRow,
          projectKeys: projectRow ? Object.keys(projectRow) : [],
          projectBudget: projectRow?.budget ?? 'NOT_FOUND',
          expenseRowCount,
          totalSpent,
        });
      }

      // Fallback: raw DB connection (must use same DB as webhook - set DATABASE_URL to Supabase connection string)
      if (!projectRow && initializeDatabase()) {
        const dbConnection = initializeDatabase();
        const projectResult = await dbConnection.execute(sql`
          SELECT id, name, budget, currency, status, created_at
          FROM projects
          WHERE id = ${projectId} AND user_id = ${userId}
          LIMIT 1
        `);
        projectRow = Array.isArray(projectResult) ? projectResult[0] : (projectResult?.rows?.[0] ?? projectResult);

        if (projectRow) {
          // CRITICAL: exclude soft-deleted expenses from every aggregate.
          // Missing this filter caused silent inflation of totals when the
          // Supabase client path was unavailable.
          const expenseResult = await dbConnection.execute(sql`
            SELECT amount, expense_date, created_at, category, deleted_at
            FROM expenses
            WHERE project_id = ${projectId}
              AND deleted_at IS NULL
          `);
          const rows = Array.isArray(expenseResult) ? expenseResult : (expenseResult?.rows || []);
          totalSpent = sumExpenses(rows);
          expenseRowsForCumulative = rows;
        }

        if (projectRow) {
          try {
            const matResult = await dbConnection.execute(sql`
              SELECT id, name, quantity, unit, unit_cost, low_stock_threshold
              FROM materials_inventory
              WHERE project_id = ${projectId}
            `);
            materialsRows = Array.isArray(matResult) ? matResult : (matResult?.rows || []);
          } catch (matErr) {
            console.warn('[Summary] materials_inventory query failed:', matErr?.message);
          }
        }

        console.log('[Summary Debug]', {
          projectId,
          source: 'database',
          projectFound: !!projectRow,
          projectBudget: projectRow?.budget ?? 'NOT_FOUND',
          totalSpent,
        });
      }

      if (!projectRow) {
        return res.status(404).json({ success: false, error: 'Project not found' });
      }

      const projectCurrency = String(projectRow.currency || 'UGX').toUpperCase();
      const budgetAmount = parseFloat(String(projectRow.budget ?? '0'));
      // Shared calculators — one source of truth across dashboard, API, and bot.
      const budgetHealth = calcBudgetPercent(totalSpent, budgetAmount);
      const firstExpense = findFirstExpenseDate(expenseRowsForCumulative);
      const burn = calcBurnRate(totalSpent, budgetAmount, firstExpense, projectCurrency);
      if (process.env.NODE_ENV !== 'production') {
        console.log('[summary]', {
          projectId,
          currency: projectCurrency,
          budget: budgetAmount,
          totalSpent,
          firstExpenseDate: firstExpense ? firstExpense.toISOString().slice(0, 10) : null,
          dailyRate: burn.dailyRate,
          daysRemaining: burn.daysRemaining,
          display: burn.displayDaysRemaining,
        });
      }
      const remaining = Math.max(0, budgetAmount - totalSpent);
      const percentage = budgetHealth.visual;
      const weeklyBurnRate = burn.weeklyRate;
      const dailyBurnRate = burn.dailyRate;
      const weeksRemaining =
        Number.isFinite(burn.daysRemaining) && weeklyBurnRate > 0
          ? burn.daysRemaining / 7
          : null;

      // Build cumulative costs by date (for Budget & Costs section)
      const byDate = {};
      for (const row of expenseRowsForCumulative) {
        const d = row.expense_date;
        const dateStr = typeof d === 'string' ? d.split('T')[0] : (d ? new Date(d).toISOString().split('T')[0] : null);
        if (dateStr) {
          byDate[dateStr] = (byDate[dateStr] || 0) + parseFloat(String(row.amount || 0));
        }
      }
      const sortedDates = Object.keys(byDate).sort();
      let running = 0;
      const cumulativeCosts = sortedDates.map((date) => {
        running += byDate[date];
        return { date, amount: Math.round(running * 100) / 100 };
      });

      const spentPercentRounded = Math.round(percentage * 10) / 10;
      const budgetSection = {
        totalBudget: budgetAmount,
        spent: totalSpent,
        remaining,
        spentPercent: spentPercentRounded,
        breakdown: budgetAmount > 0
          ? [{ category: 'Budget', amount: budgetAmount, percentage: 100, colorHex: '#218598' }]
          : [],
        vsActual:
          budgetAmount > 0 || totalSpent > 0
            ? [
                {
                  category: 'Total',
                  budgeted: budgetAmount,
                  actual: totalSpent,
                  variance:
                    budgetAmount > 0
                      ? Math.round(((totalSpent - budgetAmount) / budgetAmount) * 100)
                      : 0,
                  colorHex: '#218598',
                },
              ]
            : [],
        cumulativeCosts,
      };

      const items = materialsRows.map((row) => {
        const qty = parseFloat(String(row.quantity || 0));
        return {
          id: row.id,
          name: row.name || 'Material',
          unit: row.unit || 'units',
          unit_cost: row.unit_cost != null ? parseFloat(String(row.unit_cost)) : null,
          low_stock_threshold: row.low_stock_threshold ?? null,
          currentStock: qty,
          totalStock: qty,
          stockPercent: qty > 0 ? 100 : 0,
          consumptionVsEstimate: 0,
        };
      });
      const usage = materialsRows.map((row) => ({
        material: row.name || 'Material',
        used: 0,
        remaining: parseFloat(String(row.quantity || 0)),
      }));
      const inventoryTotalValue = calcInventoryTotal(materialsRows);
      const inventorySection = { items, usage, totalValue: inventoryTotalValue };

      // Authoritative category totals — case-folded, soft-delete aware.
      const categoryTotals = sumByCategory(expenseRowsForCumulative);

      // Projected exhaustion ISO date (YYYY-MM-DD for machine consumers).
      const budgetRunoutIso = burn.projectedExhaustionDate
        ? dateKey(burn.projectedExhaustionDate)
        : null;

      return res.json({
        success: true,
        project: {
          id: projectRow.id,
          name: projectRow.name,
          budget_amount: projectRow.budget,
          currency: projectCurrency,
          status: projectRow.status,
          created_at: projectRow.created_at,
        },
        currency: projectCurrency,
        budget: {
          total: budgetAmount,
          spent: totalSpent,
          remaining,
          percentage: Math.round(percentage * 10) / 10,
          rawPercent: Math.round(budgetHealth.raw * 10) / 10,
          status: budgetHealth.status,
          isOver: budgetHealth.isOver,
          display: budgetHealth.display,
          dailyBurnRate: Math.round(dailyBurnRate * 100) / 100,
          weeklyBurnRate: Math.round(weeklyBurnRate * 100) / 100,
          weeksRemaining: weeksRemaining != null ? Math.round(weeksRemaining * 10) / 10 : null,
          daysRemaining: Number.isFinite(burn.daysRemaining) ? burn.daysRemaining : null,
          daysRemainingDisplay: burn.displayDaysRemaining,
          isEarlyEstimate: burn.isEarlyEstimate,
          disclaimer: burn.disclaimer,
          firstExpenseDate: firstExpense ? dateKey(firstExpense) : null,
          budgetRunout: budgetRunoutIso,
          budgetRunoutDisplay: burn.projectedExhaustionDate
            ? formatProjectionDate(burn.projectedExhaustionDate)
            : null,
        },
        categoryTotals,
        inventory: {
          totalValue: inventoryTotalValue,
          itemCount: materialsRows.length,
        },
        progress: {
          // Integer 0..100 so the UI can render {progressPct}% directly without
          // floating noise or an unbounded value if data is missing.
          overallPercentage: totalTasksCount > 0
            ? Math.min(100, Math.max(0, Math.round((completedTasksCount / totalTasksCount) * 100)))
            : 0,
          completedTasks: completedTasksCount,
          totalTasks: totalTasksCount,
          phases: [],
          milestones: [],
        },
        schedule: {
          status: percentage < 70 ? 'On Track' : percentage < 90 ? 'At Risk' : 'Delayed',
          daysAhead: 0,
          daysBehind: 0,
        },
        issues: { total: openIssuesCount ?? 0, critical: criticalIssuesCount ?? 0 },
        insights: {
          topDelayCause: null,
          mostUsedMaterial: null,
          recentHighlight: null,
          progressTrend: [],
          dailyCostBurn: [],
        },
        activity: { heatmap: [] },
        budgetSection,
        inventorySection,
      });
    } catch (err) {
      console.error('[Summary Error]', err.message, err.stack);
      return res.status(500).json({ success: false, error: err.message || 'Summary failed' });
    }
  });
});

// GET /api/projects/:projectId/expenses — Budget & Costs page data (Supabase-first, same as summary)
app.get('/api/projects/:projectId/expenses', (req, res, next) => {
  requireAuth(req, res, async () => {
    const projectId = req.params.projectId;
    const userId = req.userId || req.user?.id;
    if (!userId) {
      return res.status(401).json({ success: false, error: 'Not authenticated' });
    }
    try {
      const supabaseUrl = process.env.SUPABASE_URL;
      const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
      if (!supabaseUrl || !supabaseServiceKey) {
        return res.status(500).json({ success: false, error: 'Server not configured for expenses' });
      }
      const { createClient } = await import('@supabase/supabase-js');
      const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

      const hasAccess = await userHasProjectAccess(supabase, projectId, userId);
      if (!hasAccess) {
        return res.status(404).json({ success: false, error: 'Project not found' });
      }
      const { data: projectRow } = await supabase
        .from('projects')
        .select('id, name, budget, currency')
        .eq('id', projectId)
        .maybeSingle();
      if (!projectRow) {
        return res.status(404).json({ success: false, error: 'Project not found' });
      }

      const budgetTotal = parseFloat(String(projectRow.budget || 0));
      const projectCurrency = String(projectRow.currency || 'UGX').toUpperCase();

      let expenseRows;
      let expError;
      let expenseQuery = supabase
        .from('expenses')
        .select('id, description, amount, expense_date, source, created_at, disputed, category')
        .eq('project_id', projectId)
        .is('deleted_at', null)
        .order('created_at', { ascending: false });
      const result = await expenseQuery;
      expError = result.error;
      expenseRows = result.data;
      if (expError && (expError.message || '').toLowerCase().includes('category')) {
        const fallback = await supabase
        .from('expenses')
        .select('id, description, amount, expense_date, source, created_at, disputed')
        .eq('project_id', projectId)
        .is('deleted_at', null)
        .order('created_at', { ascending: false });
        expError = fallback.error;
        expenseRows = (fallback.data || []).map((e) => ({ ...e, category: null }));
      }

      if (expError) {
        console.error('[Expenses]', expError);
        return res.status(500).json({ success: false, error: expError.message });
      }

      const expenses = expenseRows || [];
      // Shared, float-safe totals + unified burn-rate formula.
      const spent = sumExpenses(expenses);
      const remaining = Math.max(0, budgetTotal - spent);
      const budgetHealth = calcBudgetPercent(spent, budgetTotal);
      const firstExpenseDate = findFirstExpenseDate(expenses);
      const burn = calcBurnRate(spent, budgetTotal, firstExpenseDate, projectCurrency);
      const percentage = budgetHealth.visual;
      const weeklyBurnRate = burn.weeklyRate;
      const dailyBurnRate = burn.dailyRate;
      const weeksRemaining =
        Number.isFinite(burn.daysRemaining) && weeklyBurnRate > 0
          ? burn.daysRemaining / 7
          : null;

      const summary = {
        total: budgetTotal,
        spent,
        remaining,
        percentage: Math.round(percentage * 10) / 10,
        rawPercent: Math.round(budgetHealth.raw * 10) / 10,
        status: budgetHealth.status,
        isOver: budgetHealth.isOver,
        display: budgetHealth.display,
        dailyBurnRate: Math.round(dailyBurnRate * 100) / 100,
        weeklyBurnRate: Math.round(weeklyBurnRate * 100) / 100,
        weeksRemaining: weeksRemaining != null ? Math.round(weeksRemaining * 10) / 10 : null,
        daysRemaining: Number.isFinite(burn.daysRemaining) ? burn.daysRemaining : null,
        daysRemainingDisplay: burn.displayDaysRemaining,
        isEarlyEstimate: burn.isEarlyEstimate,
        disclaimer: burn.disclaimer,
        currency: projectCurrency,
      };

      // Case-folded, soft-delete aware category totals via shared helper.
      // Prevents "Materials"/"materials"/"MATERIALS" from splitting into three
      // buckets where each shows <100% of the true category share.
      const byCategory = sumByCategory(expenses).map((c) => ({
        category: c.name,
        total: c.amount,
        count: c.count,
        percentage: c.percent,
      }));

      // This week / last week totals for spending spike alert
      const now = new Date();
      const getWeekBounds = (date) => {
        const d = new Date(date);
        d.setHours(0, 0, 0, 0);
        const day = d.getDay();
        const diff = d.getDate() - day + (day === 0 ? -6 : 1);
        const monday = new Date(d.getFullYear(), d.getMonth(), diff);
        const sunday = new Date(monday);
        sunday.setDate(sunday.getDate() + 6);
        sunday.setHours(23, 59, 59, 999);
        return { start: monday.getTime(), end: sunday.getTime() };
      };
      const thisWeek = getWeekBounds(now);
      const lastWeekStart = thisWeek.start - 7 * 24 * 60 * 60 * 1000;
      const lastWeekEnd = thisWeek.end - 7 * 24 * 60 * 60 * 1000;
      let thisWeekTotal = 0;
      let lastWeekTotal = 0;
      for (const e of expenses) {
        const t = new Date(e.expense_date || e.created_at).getTime();
        if (t >= thisWeek.start && t <= thisWeek.end) thisWeekTotal += parseFloat(String(e.amount || 0));
        if (t >= lastWeekStart && t <= lastWeekEnd) lastWeekTotal += parseFloat(String(e.amount || 0));
      }

      const sixMonthsAgo = new Date();
      sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
      const byMonthMap = {};
      for (const e of expenses) {
        const d = e.expense_date;
        const dateStr = typeof d === 'string' ? d.split('T')[0] : (d ? new Date(d).toISOString().split('T')[0] : null);
        if (!dateStr || new Date(dateStr) < sixMonthsAgo) continue;
        const monthKey = dateStr.substring(0, 7);
        const monthLabel = new Date(dateStr + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
        if (!byMonthMap[monthKey]) byMonthMap[monthKey] = { month: monthLabel, amount: 0, sortKey: monthKey };
        byMonthMap[monthKey].amount += parseFloat(String(e.amount || 0));
      }
      const byMonth = Object.values(byMonthMap).sort((a, b) => a.sortKey.localeCompare(b.sortKey)).map(({ month, amount }) => ({ month, amount }));

      const toClientExpense = (e) => ({
        id: e.id,
        description: e.description || '',
        amount: parseFloat(String(e.amount || 0)),
        // Normalize: "materials"/"MATERIALS"/"  Labour  " → canonical title case;
        // null/empty → "Uncategorized".
        category: normalizeCategory(e.category),
        expense_date: e.expense_date,
        vendor: null,
        source: e.source || null,
        created_at: e.created_at,
        disputed: !!e.disputed,
      });
      const recent = expenses.slice(0, 20).map(toClientExpense);
      const expensesForClient = expenses.map(toClientExpense);

      let vendors = [];
      try {
        const { data: vendorRows } = await supabase
          .from('vendors')
          .select('name, total_spent')
          .eq('project_id', projectId)
          .order('total_spent', { ascending: false })
          .limit(10);
        vendors = (vendorRows || []).map((v) => ({
          name: v.name || '',
          total: parseFloat(String(v.total_spent || 0)),
          count: 0,
        }));
      } catch (_) { /* vendors table may not exist */ }

      return res.json({
        success: true,
        currency: projectCurrency,
        summary,
        byCategory,
        byMonth,
        recent,
        expenses: expensesForClient,
        vendors,
        thisWeekTotal: Math.round(thisWeekTotal * 100) / 100,
        lastWeekTotal: Math.round(lastWeekTotal * 100) / 100,
      });
    } catch (err) {
      console.error('[Expenses API Error]', err.message, err.stack);
      return res.status(500).json({ success: false, error: err.message || 'Failed to load expenses' });
    }
  });
});

// POST /api/projects/:projectId/expenses — Log expense from dashboard
// If body includes item + quantity (or description parses as material), also upserts materials_inventory.
const MATERIAL_KEYWORDS = [
  'cement', 'sand', 'gravel', 'bricks', 'iron bars', 'steel', 'timber', 'wood',
  'poles', 'tiles', 'paint', 'roofing', 'pipes', 'wire', 'aggregate', 'ballast',
  'blocks', 'stone',
];
function parseMaterialFromDescription(desc) {
  if (!desc || typeof desc !== 'string') return null;
  const m = desc.trim().match(/^(\d+(?:\.\d+)?)\s*(bags?|tonnes?|pieces?|bars?|sheets?|litres?|rolls?|units?)?\s*(?:of\s+)?(.+)$/i);
  if (m) {
    const qty = parseFloat(m[1]);
    const unit = (m[2] || 'units').toLowerCase();
    const item = m[3].trim();
    if (item && !isNaN(qty) && qty > 0) return { quantity: qty, unit: unit || 'units', item };
  }
  const fallback = desc.match(/(\d+)\s*(bags?|pieces?|units?|kg|tons?)?/i);
  if (fallback) {
    const item = desc.replace(fallback[0], '').replace(/\s*(?:for|@|at)\s*[\d,.]+\s*$/i, '').trim();
    if (item.length > 1 && MATERIAL_KEYWORDS.some((k) => item.toLowerCase().includes(k))) {
      return { quantity: parseFloat(fallback[1]), unit: (fallback[2] || 'units').toLowerCase(), item };
    }
  }
  return null;
}

app.post('/api/projects/:projectId/expenses', requireAuth, async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const userId = req.userId || req.user?.id;
    if (!userId) {
      console.error('[POST expenses] No userId — not authenticated');
      return res.status(401).json({ success: false, error: 'Not authenticated' });
    }
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      console.error('[POST expenses] Supabase not configured');
      return res.status(500).json({ success: false, error: 'Server not configured' });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });
    const { data: projectRow } = await supabase
      .from('projects')
      .select('id, currency')
      .eq('id', projectId)
      .eq('user_id', userId)
      .maybeSingle();
    if (!projectRow) {
      console.error('[POST expenses] Project not found:', projectId);
      return res.status(404).json({ success: false, error: 'Project not found' });
    }
    const body = req.body || {};
    const { description, category, vendor, expense_date } = body;
    const rawAmount = body.amount ?? body.Amount ?? 0;
    const amount = parseFloat(
      String(rawAmount).replace(/,/g, '').replace(/[^0-9.]/g, '')
    );
    if (isNaN(amount) || amount <= 0) {
      return res.status(400).json({ success: false, error: 'Invalid amount' });
    }
    const today = (expense_date || new Date().toISOString().split('T')[0]).toString().substring(0, 10);
    // Inherit currency from the project — never hardcode UGX.
    const insertPayload = {
      project_id: projectId,
      user_id: userId,
      description: (description && String(description).trim()) ? String(description).trim() : 'Expense',
      amount,
      expense_date: today,
      currency: String(projectRow.currency || 'UGX').toUpperCase(),
      source: body.source || 'dashboard',
    };
    if (category !== undefined) insertPayload.category = normalizeCategory(category);
    if (vendor !== undefined) insertPayload.vendor = vendor && String(vendor).trim() ? String(vendor).trim() : null;

    const { data: expense, error } = await supabase
      .from('expenses')
      .insert(insertPayload)
      .select()
      .single();

    if (error) {
      console.error('[POST expenses] Supabase insert error:', error.message, error.details || '');
      return res.status(500).json({
        success: false,
        error: error.message || 'Failed to log expense',
      });
    }

    // If expense looks like a material purchase, upsert materials_inventory so Materials page shows it
    let quantity = body.quantity != null ? parseFloat(String(body.quantity)) : NaN;
    let unit = body.unit && String(body.unit).trim() ? String(body.unit).trim() : 'units';
    let itemName = body.item && String(body.item).trim() ? String(body.item).trim() : null;
    if ((!itemName || isNaN(quantity) || quantity <= 0) && description) {
      const parsed = parseMaterialFromDescription(description);
      if (parsed) {
        quantity = parsed.quantity;
        unit = parsed.unit || unit;
        itemName = parsed.item;
      }
    }
    if (itemName && quantity > 0) {
      const now = new Date().toISOString();
      const unitCost = amount && quantity > 0 ? amount / quantity : 0;
      const totalCost = amount || quantity * unitCost;
      const nameNorm = normalizeMaterialStorageName(itemName);
      const { data: existing } = await supabase
        .from('materials_inventory')
        .select('id, quantity, unit_cost, total_cost')
        .eq('project_id', projectId)
        .eq('name', nameNorm)
        .maybeSingle();
      if (existing) {
        const newQty = parseFloat(String(existing.quantity || 0)) + quantity;
        const newTotalCost = parseFloat(String(existing.total_cost || 0)) + totalCost;
        await supabase
          .from('materials_inventory')
          .update({
            quantity: newQty,
            unit_cost: unitCost || parseFloat(String(existing.unit_cost || 0)),
            total_cost: newTotalCost,
            last_purchased_at: now,
            updated_at: now,
          })
          .eq('id', existing.id);
        await supabase.from('material_transactions').insert({
          material_id: existing.id,
          project_id: projectId,
          user_id: userId,
          transaction_type: 'purchase',
          quantity,
          unit_cost: unitCost,
          total_cost: totalCost,
          description: `Dashboard: ${description || itemName}`,
          source: 'dashboard',
        });
      } else {
        const { data: inserted } = await supabase
          .from('materials_inventory')
          .insert({
            project_id: projectId,
            user_id: userId,
            name: nameNorm,
            quantity,
            unit: unit || 'units',
            unit_cost: unitCost,
            total_cost: totalCost,
            source: 'dashboard',
            last_purchased_at: now,
            updated_at: now,
          })
          .select('id')
          .single();
        if (inserted && inserted.id) {
          await supabase.from('material_transactions').insert({
            material_id: inserted.id,
            project_id: projectId,
            user_id: userId,
            transaction_type: 'purchase',
            quantity,
            unit_cost: unitCost,
            total_cost: totalCost,
            description: `Dashboard: ${description || itemName}`,
            source: 'dashboard',
          });
        }
      }
    }

    return res.status(201).json({ success: true, expense: expense || {} });
  } catch (err) {
    console.error('[POST expenses] Unexpected error:', err?.message, err?.stack || '');
    return res.status(500).json({
      success: false,
      error: err?.message || 'Server error',
    });
  }
});

// DELETE /api/expenses/:id — Delete expense (ownership: expense must belong to user's project)
app.delete('/api/expenses/:id', requireAuth, async (req, res) => {
  try {
    const expenseId = req.params.id;
    const userId = req.userId || req.user?.id;
    if (!userId) {
      return res.status(401).json({ success: false, error: 'Not authenticated' });
    }
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, error: 'Server not configured' });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

    // Only operate on non-deleted rows — prevents re-running delete on a
    // already-soft-deleted expense from re-triggering cache invalidations.
    const { data: expenseRow, error: fetchErr } = await supabase
      .from('expenses')
      .select('id, project_id')
      .eq('id', expenseId)
      .is('deleted_at', null)
      .maybeSingle();
    if (fetchErr || !expenseRow) {
      return res.status(404).json({ success: false, error: 'Expense not found' });
    }
    const { data: projectRow } = await supabase
      .from('projects')
      .select('id')
      .eq('id', expenseRow.project_id)
      .eq('user_id', userId)
      .maybeSingle();
    if (!projectRow) {
      return res.status(404).json({ success: false, error: 'Expense not found' });
    }
    // Soft delete — preserves audit trail and matches the rest of the product.
    const { error: deleteErr } = await supabase
      .from('expenses')
      .update({ deleted_at: new Date().toISOString() })
      .eq('id', expenseId)
      .is('deleted_at', null);
    if (deleteErr) {
      console.error('[DELETE expense]', deleteErr.message);
      return res.status(500).json({ success: false, error: deleteErr.message || 'Failed to delete' });
    }
    return res.json({ success: true });
  } catch (err) {
    console.error('[DELETE expense] Unexpected error:', err?.message, err?.stack || '');
    return res.status(500).json({ success: false, error: err?.message || 'Server error' });
  }
});

// PATCH /api/expenses/:id — Update expense (ownership: expense must belong to user's project)
app.patch('/api/expenses/:id', requireAuth, async (req, res) => {
  try {
    const expenseId = req.params.id;
    const userId = req.userId || req.user?.id;
    if (!userId) {
      return res.status(401).json({ success: false, error: 'Not authenticated' });
    }
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, error: 'Server not configured' });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

    // Only permit edits on non-soft-deleted rows — matches DELETE behaviour.
    const { data: expenseRow, error: fetchErr } = await supabase
      .from('expenses')
      .select('id, project_id')
      .eq('id', expenseId)
      .is('deleted_at', null)
      .maybeSingle();
    if (fetchErr || !expenseRow) {
      return res.status(404).json({ success: false, error: 'Expense not found' });
    }
    const { data: projectRow } = await supabase
      .from('projects')
      .select('id')
      .eq('id', expenseRow.project_id)
      .eq('user_id', userId)
      .maybeSingle();
    if (!projectRow) {
      return res.status(404).json({ success: false, error: 'Expense not found' });
    }
    const body = req.body || {};
    const description = body.description != null ? String(body.description).trim() || 'Expense' : undefined;
    const rawAmount = body.amount;
    const amount = rawAmount != null ? parseFloat(String(rawAmount).replace(/,/g, '').replace(/[^0-9.]/g, '')) : undefined;
    if (amount !== undefined && (isNaN(amount) || amount < 0)) {
      return res.status(400).json({ success: false, error: 'Invalid amount' });
    }
    const updates = { updated_at: new Date().toISOString() };
    if (description !== undefined) updates.description = description;
    if (amount !== undefined) updates.amount = amount;
    if (body.category !== undefined) updates.category = normalizeCategory(body.category);

    const { data: updated, error: updateErr } = await supabase
      .from('expenses')
      .update(updates)
      .eq('id', expenseId)
      .is('deleted_at', null)
      .select()
      .single();
    if (updateErr) {
      console.error('[PATCH expense]', updateErr.message);
      return res.status(500).json({ success: false, error: updateErr.message || 'Failed to update' });
    }
    return res.json({ success: true, expense: updated });
  } catch (err) {
    console.error('[PATCH expense] Unexpected error:', err?.message, err?.stack || '');
    return res.status(500).json({ success: false, error: err?.message || 'Server error' });
  }
});

// POST /api/projects/:projectId/issues — Report issue (issues table)
app.post('/api/projects/:projectId/issues', requireAuth, async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const userId = req.userId || req.user?.id;
    if (!userId) return res.status(401).json({ success: false, error: 'Not authenticated' });
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, error: 'Server not configured' });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });
    const { data: projectRow } = await supabase.from('projects').select('id').eq('id', projectId).eq('user_id', userId).maybeSingle();
    if (!projectRow) return res.status(404).json({ success: false, error: 'Project not found' });
    const { title, description, severity, type, status, priority } = req.body || {};
    const { error } = await supabase.from('issues').insert({
      project_id: projectId,
      title: title && String(title).trim() ? String(title).trim() : 'Untitled issue',
      description: description != null ? String(description) : '',
      severity: severity || priority || 'medium',
      type: type || 'general',
      status: status || 'open',
    });
    if (error) {
      console.error('[POST issues]', error.message, error);
      return res.status(500).json({ success: false, error: error.message || 'Failed to report issue' });
    }
    return res.status(201).json({ success: true });
  } catch (err) {
    console.error('[POST issues] Unexpected error:', err?.message, err?.stack);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to report issue' });
  }
});

// GET /api/projects/:projectId/tasks — List tasks for project (Vercel)
app.get('/api/projects/:projectId/tasks', requireAuth, async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const userId = req.userId || req.user?.id;
    if (!userId) return res.status(401).json({ success: false, error: 'Not authenticated' });
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, tasks: [], error: 'Server not configured' });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });
    const { data: projectRow } = await supabase.from('projects').select('id').eq('id', projectId).eq('user_id', userId).maybeSingle();
    if (!projectRow) return res.status(404).json({ success: false, tasks: [], error: 'Project not found' });
    const { data, error } = await supabase
      .from('tasks')
      .select('*')
      .eq('project_id', projectId)
      .order('created_at', { ascending: false });
    if (error) {
      console.error('[GET tasks]', error.message);
      return res.status(500).json({ success: false, tasks: [], error: error.message });
    }
    return res.json({ success: true, tasks: data ?? [] });
  } catch (err) {
    console.error('[GET tasks] Unexpected error:', err?.message, err?.stack);
    return res.status(500).json({ success: false, tasks: [], error: err?.message || 'Server error' });
  }
});

// GET /api/projects/:projectId/issues — List issues for Issues & Risks section
app.get('/api/projects/:projectId/issues', requireAuth, async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const userId = req.userId || req.user?.id;
    if (!userId) return res.status(401).json({ success: false, error: 'Not authenticated' });
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, issues: [], error: 'Server not configured' });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });
    const { data: projectRow } = await supabase.from('projects').select('id').eq('id', projectId).eq('user_id', userId).maybeSingle();
    if (!projectRow) return res.status(404).json({ success: false, issues: [], error: 'Project not found' });
    const { data, error } = await supabase
      .from('issues')
      .select('*')
      .eq('project_id', projectId)
      .order('created_at', { ascending: false });
    if (error) {
      console.error('[GET issues]', error.message);
      return res.status(500).json({ success: false, issues: [], error: error.message });
    }
    return res.json({ success: true, issues: data ?? [] });
  } catch (err) {
    console.error('[GET issues] Unexpected error:', err?.message, err?.stack);
    return res.status(500).json({ success: false, issues: [], error: err?.message || 'Server error' });
  }
});

// PATCH /api/issues/:id — Update issue (e.g. acknowledge)
app.patch('/api/issues/:id', requireAuth, async (req, res) => {
  try {
    const issueId = req.params.id;
    const userId = req.userId || req.user?.id;
    if (!userId) return res.status(401).json({ success: false, error: 'Not authenticated' });
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, error: 'Server not configured' });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });
    const { data: issueRow, error: fetchErr } = await supabase
      .from('issues')
      .select('id, project_id')
      .eq('id', issueId)
      .maybeSingle();
    if (fetchErr || !issueRow) {
      return res.status(404).json({ success: false, error: 'Issue not found' });
    }
    const { data: projectRow } = await supabase
      .from('projects')
      .select('id, user_id, manager_id')
      .eq('id', issueRow.project_id)
      .maybeSingle();
    if (!projectRow) {
      return res.status(404).json({ success: false, error: 'Project not found' });
    }
    const isOwner = projectRow.user_id === userId;
    const isManager = projectRow.manager_id && projectRow.manager_id === userId;
    if (!isOwner && !isManager) {
      return res.status(403).json({ success: false, error: 'Not allowed to update this issue' });
    }
    const { status } = req.body || {};
    const updates = {};
    if (typeof status === 'string' && status.trim()) {
      updates.status = status.trim();
      if (updates.status === 'acknowledged') {
        updates.acknowledged_at = new Date().toISOString();
      }
    }
    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ success: false, error: 'No valid updates' });
    }
    const { data: updated, error: updateErr } = await supabase
      .from('issues')
      .update(updates)
      .eq('id', issueId)
      .select()
      .single();
    if (updateErr) {
      console.error('[PATCH issues]', updateErr.message);
      return res.status(500).json({ success: false, error: updateErr.message });
    }
    return res.json({ success: true, issue: updated });
  } catch (err) {
    console.error('[PATCH issues] Unexpected error:', err?.message, err?.stack);
    return res.status(500).json({ success: false, error: err?.message || 'Server error' });
  }
});

// GET /api/daily-logs — Fetch daily log for a specific project and date
// Query params: project_id (required), date (YYYY-MM-DD, optional - defaults to today)
app.get('/api/daily-logs', requireAuth, async (req, res) => {
  try {
    const userId = req.userId || req.user?.id;
    if (!userId) return res.status(401).json({ success: false, error: 'Not authenticated' });
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, error: 'Server not configured' });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });
    
    const projectId = req.query.project_id;
    const date = req.query.date || new Date().toISOString().split('T')[0];
    
    if (!projectId) return res.status(400).json({ success: false, error: 'project_id is required' });
    
    // Verify project belongs to user (or user is manager)
    const { data: projectRow } = await supabase.from('projects').select('id').eq('id', projectId).or(`user_id.eq.${userId},manager_id.eq.${userId}`).maybeSingle();
    if (!projectRow) return res.status(404).json({ success: false, error: 'Project not found' });
    
    // Fetch the daily log for this date
    const { data: logRow, error } = await supabase
      .from('daily_logs')
      .select('id, log_date, worker_count, notes, milestones, milestone_count, activity_entries, photo_urls, created_at')
      .eq('project_id', projectId)
      .eq('log_date', date)
      .maybeSingle();
    
    if (error) {
      console.error('[GET /api/daily-logs]', error);
      return res.status(500).json({ success: false, error: error.message });
    }
    
    const log = logRow ? {
      ...logRow,
      photo_urls: normalizePhotoUrls(logRow.photo_urls).map((p) => p.url),
    } : null;
    return res.json({ success: true, data: log });
  } catch (err) {
    console.error('[GET /api/daily-logs]', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch daily log' });
  }
});

// POST /api/daily-logs — Daily site log: { project_id, log_date, entry } or { project_id, log_date, entries, ... }
// Supports both single entry append and bulk entries replacement
app.post('/api/daily-logs', requireAuth, async (req, res) => {
  try {
    const userId = req.userId || req.user?.id;
    if (!userId) return res.status(401).json({ success: false, error: 'Not authenticated' });
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, error: 'Server not configured' });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });
    const { project_id, log_date, worker_count, entries, entry, milestones, milestone_count, notes } = req.body;
    const projectId = project_id;
    if (!projectId) return res.status(400).json({ success: false, error: 'project_id is required' });
    const { data: projectRow } = await supabase.from('projects').select('id').eq('id', projectId).or(`user_id.eq.${userId},manager_id.eq.${userId}`).maybeSingle();
    if (!projectRow) return res.status(404).json({ success: false, error: 'Project not found' });
    const today = (log_date || new Date().toISOString().split('T')[0]).toString().substring(0, 10);
    
    // Check if we have a single entry to append or multiple entries
    let newActivityEntries = [];
    if (entry && typeof entry === 'object') {
      // Single entry append mode
      newActivityEntries = [{
        log_time: entry.log_time || new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }).toLowerCase(),
        activity_type: entry.activity_type || 'Entry',
        description: entry.description || '',
        amount: entry.amount != null ? parseFloat(entry.amount) : null,
        photo_urls: entry.photo_urls || [],
        worker_count: entry.worker_count != null ? parseInt(entry.worker_count) : null,
        author: entry.author || null,
        source: entry.source || 'dashboard',
      }];
    } else if (Array.isArray(entries)) {
      // Bulk entries mode
      newActivityEntries = entries.map(e => ({
        log_time: e.log_time || null,
        activity_type: e.activity_type || 'Other',
        description: e.description || '',
        amount: e.amount != null ? parseFloat(e.amount) : null,
        photo_urls: e.photo_urls || [],
        worker_count: e.worker_count != null ? parseInt(e.worker_count) : null,
        author: e.author || null,
        source: e.source || 'dashboard',
      }));
    }
    
    const { data: existing } = await supabase
      .from('daily_logs')
      .select('id, notes, activity_entries, worker_count')
      .eq('project_id', projectId)
      .eq('log_date', today)
      .maybeSingle();
    
    if (existing) {
      const updateData = {
        worker_count: worker_count != null ? worker_count : existing.worker_count,
        updated_at: new Date().toISOString(),
      };
      
      // Append new entries to existing entries
      const existingEntries = existing.activity_entries || [];
      if (newActivityEntries.length > 0) {
        updateData.activity_entries = [...existingEntries, ...newActivityEntries];
      }
      
      if (milestones !== undefined) updateData.milestones = milestones == null ? null : String(milestones).trim();
      if (milestone_count !== undefined) {
        const mc = parseInt(String(milestone_count), 10);
        updateData.milestone_count = Number.isFinite(mc) ? mc : 0;
      }
      if (notes !== undefined) updateData.notes = notes == null ? '' : String(notes).trim();
      
      const { data: updated, error: updateError } = await supabase
        .from('daily_logs')
        .update(updateData)
        .eq('id', existing.id)
        .select()
        .single();
        
      if (updateError) throw updateError;
      return res.status(200).json({ success: true, data: updated });
    } else {
      const { data: inserted, error: insertError } = await supabase
        .from('daily_logs')
        .insert({
          project_id: projectId,
          log_date: today,
          worker_count: worker_count != null ? worker_count : null,
          notes: notes != null ? String(notes).trim() : '',
          milestones: milestones != null ? String(milestones).trim() : null,
          milestone_count: milestone_count != null ? (parseInt(String(milestone_count), 10) || 0) : 0,
          activity_entries: newActivityEntries.length > 0 ? newActivityEntries : [],
          created_at: new Date().toISOString(),
        })
        .select()
        .single();
        
      if (insertError) throw insertError;
      return res.status(201).json({ success: true, data: inserted });
    }
  } catch (err) {
    console.error('[POST /api/daily-logs]', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to save daily log' });
  }
});

// POST /api/projects/:projectId/daily/log — Daily log entry (legacy)
// Accepts: { log_date, worker_count, notes?, entries?: [{ log_time, activity_type, description, amount? }] }
app.post('/api/projects/:projectId/daily/log', requireAuth, async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const userId = req.userId || req.user?.id;
    if (!userId) return res.status(401).json({ success: false, error: 'Not authenticated' });
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, error: 'Server not configured' });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });
    const { data: projectRow } = await supabase.from('projects').select('id').eq('id', projectId).eq('user_id', userId).maybeSingle();
    if (!projectRow) return res.status(404).json({ success: false, error: 'Project not found' });
    const { worker_count, notes, log_date, entries } = req.body;
    const today = (log_date || new Date().toISOString().split('T')[0]).toString().substring(0, 10);
    const activityEntries = Array.isArray(entries) ? entries.map(e => ({
      log_time: e.log_time || null,
      activity_type: e.activity_type || 'Other',
      description: e.description || '',
      amount: e.amount != null ? parseFloat(e.amount) : null,
    })) : [];
    const { data: existing } = await supabase.from('daily_logs').select('id, notes, activity_entries').eq('project_id', projectId).eq('log_date', today).maybeSingle();
    if (existing) {
      const updateData = {
        worker_count: worker_count != null ? worker_count : existing.worker_count,
        updated_at: new Date().toISOString(),
      };
      if (notes != null) updateData.notes = notes ? (existing.notes ? `${existing.notes}\n${notes}` : notes) : existing.notes;
      if (activityEntries.length > 0) updateData.activity_entries = activityEntries;
      await supabase.from('daily_logs').update(updateData).eq('id', existing.id);
    } else {
      await supabase.from('daily_logs').insert({
        project_id: projectId,
        log_date: today,
        worker_count: worker_count != null ? worker_count : null,
        notes: notes || '',
        activity_entries: activityEntries.length > 0 ? activityEntries : [],
        created_at: new Date().toISOString(),
      });
    }
    return res.status(201).json({ success: true });
  } catch (err) {
    console.error('[POST daily/log]', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to save daily log' });
  }
});

// POST /api/projects/:projectId/daily/photo — Register photo URL in daily log (client uploads to Storage first)
app.post('/api/projects/:projectId/daily/photo', requireAuth, async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const userId = req.userId || req.user?.id;
    if (!userId) {
      console.error('[POST daily/photo] No userId');
      return res.status(401).json({ success: false, error: 'Not authenticated' });
    }
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      console.error('[POST daily/photo] Supabase not configured');
      return res.status(500).json({ success: false, error: 'Server not configured' });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });
    const { data: projectRow } = await supabase.from('projects').select('id').eq('id', projectId).eq('user_id', userId).maybeSingle();
    if (!projectRow) {
      console.error('[POST daily/photo] Project not found:', projectId);
      return res.status(404).json({ success: false, error: 'Project not found' });
    }
    const { photoUrl, caption, tag } = req.body || {};
    if (!photoUrl || typeof photoUrl !== 'string' || !photoUrl.startsWith('http')) {
      return res.status(400).json({ success: false, error: 'Valid photoUrl required' });
    }

    const today = new Date().toISOString().split('T')[0];
    const { data: existing } = await supabase
      .from('daily_logs')
      .select('id, photo_urls')
      .eq('project_id', projectId)
      .eq('log_date', today)
      .maybeSingle();

    const captionStr = typeof caption === 'string' ? caption.trim() || null : null;
    const tagStr = typeof tag === 'string' ? tag.trim() || null : null;
    const newEntry = { url: photoUrl, caption: captionStr, tag: tagStr };

    const raw = existing?.photo_urls;
    let entries = normalizePhotoUrls(raw);
    entries.push(newEntry);

    if (existing) {
      const { error: updateErr } = await supabase
        .from('daily_logs')
        .update({ photo_urls: entries })
        .eq('id', existing.id);
      if (updateErr) {
        console.error('[POST daily/photo] daily_logs update error:', updateErr.message);
        return res.status(500).json({ success: false, error: updateErr.message || 'Failed to save photo URL' });
      }
    } else {
      const { error: insertErr } = await supabase.from('daily_logs').insert({
        project_id: projectId,
        log_date: today,
        worker_count: 0,
        notes: '',
        photo_urls: entries,
        created_at: new Date().toISOString(),
      });
      if (insertErr) {
        console.error('[POST daily/photo] daily_logs insert error:', insertErr.message);
        return res.status(500).json({ success: false, error: insertErr.message || 'Failed to save photo' });
      }
    }
    return res.status(201).json({ success: true, url: photoUrl });
  } catch (err) {
    console.error('[POST daily/photo] Unexpected error:', err?.message || err, err?.stack || '');
    return res.status(500).json({ success: false, error: err?.message || 'Failed to save photo' });
  }
});

// GET /api/projects/:projectId/materials — Materials & Inventory page
app.get('/api/projects/:projectId/materials', (req, res, next) => {
  requireAuth(req, res, async () => {
    const projectId = req.params.projectId;
    const userId = req.userId || req.user?.id;
    if (!userId) {
      return res.status(401).json({ success: false, error: 'Not authenticated' });
    }
    try {
      const supabaseUrl = process.env.SUPABASE_URL;
      const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
      if (!supabaseUrl || !supabaseServiceKey) {
        return res.status(500).json({ success: false, error: 'Server not configured' });
      }
      const { createClient } = await import('@supabase/supabase-js');
      const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

      const allowed = await userHasProjectAccess(supabase, projectId, userId);
      if (!allowed) {
        return res.status(404).json({ success: false, error: 'Project not found' });
      }

      const { data: rows, error } = await supabase
        .from('materials_inventory')
        .select('*')
        .eq('project_id', projectId)
        .order('name', { ascending: true });
      if (error) {
        console.error('[Materials GET]', error.message);
        return res.status(500).json({ success: false, error: error.message || 'Failed to load materials' });
      }

      const inventory = (rows || []).map((r) => ({
        id: r.id,
        project_id: r.project_id,
        name: r.name,
        quantity: parseFloat(String(r.quantity || 0)),
        unit: r.unit || 'units',
        last_updated: r.last_updated || r.updated_at || null,
        created_at: r.created_at || null,
        user_id: r.user_id || null,
        unit_cost: r.unit_cost != null ? parseFloat(String(r.unit_cost)) : null,
        total_cost: r.total_cost != null ? parseFloat(String(r.total_cost)) : null,
        low_stock_threshold: r.low_stock_threshold != null ? parseFloat(String(r.low_stock_threshold)) : 5,
        last_purchased_at: r.last_purchased_at || null,
        last_used_at: r.last_used_at || null,
        source: r.source || 'manual',
        notes: r.notes || null,
        updated_at: r.updated_at || null,
      }));
      const lowStockThresholdDefault = 5;
      const lowStock = inventory.filter((m) => m.quantity <= (m.low_stock_threshold ?? lowStockThresholdDefault)).map((m) => ({
        name: m.name,
        quantity: m.quantity,
        unit: m.unit,
        low_stock_threshold: m.low_stock_threshold,
      }));
      const lastUpdated = inventory.length
        ? inventory.reduce((latest, m) => {
            const t = (m.updated_at || m.last_updated) ? new Date(m.updated_at || m.last_updated).getTime() : 0;
            return t > latest ? t : latest;
          }, 0)
        : null;
      // Total inventory value = Σ(quantity × unit_cost) — current stock at current price
      const totalInventoryValue = inventory.reduce(
        (s, m) => s + (m.quantity || 0) * (m.unit_cost || 0),
        0
      );
      const summary = {
        totalItems: inventory.length,
        totalInventoryValue: Math.round(totalInventoryValue),
        lowStockCount: lowStock.length,
        lastUpdated: lastUpdated ? new Date(lastUpdated).toISOString() : null,
      };

      return res.json({
        success: true,
        inventory,
        lowStock,
        usage: [],
        summary,
      });
    } catch (err) {
      console.error('[Materials API Error]', err.message, err.stack);
      return res.status(500).json({ success: false, error: err.message || 'Failed to load materials' });
    }
  });
});

function utcDateKeyFromIso(iso) {
  if (!iso) return '';
  return new Date(iso).toISOString().split('T')[0];
}

/** Keep in sync with shared/materialNames.ts */
// Words that must never be singularized (would produce wrong stems)
const _MAT_KEEP = new Set([
  'glass', 'grass', 'brass', 'gas', 'canvas', 'status', 'access', 'rebar',
  'hardcore', 'murram', 'gravel', 'ballast', 'aggregate', 'cement',
]);
function singularizeMaterialToken(w) {
  if (w.length < 2) return w;
  if (_MAT_KEEP.has(w)) return w;
  // possessive: "mason's" → "mason"
  if (w.endsWith("'s")) return w.slice(0, -2);
  // -ies → -y: "lorries" → "lorry"
  if (w.endsWith('ies') && w.length > 4) return w.slice(0, -3) + 'y';
  // General -s removal (handles tiles→tile, pipes→pipe, bricks→brick, cements→cement)
  // Keeps double-s words (glass, grass, brass) via _MAT_KEEP above
  if (w.endsWith('s') && !w.endsWith('ss') && w.length >= 4) {
    const stem = w.slice(0, -1);
    if (stem.length >= 3) return stem;
  }
  return w;
}
function normalizeMaterialStorageName(raw) {
  const s = String(raw || '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ');
  if (!s) return '';
  return s.split(/\s+/).map(singularizeMaterialToken).join(' ');
}

// GET /api/projects/:projectId/materials/daily — Vercel: same as Express (materials calendar + by-date entries)
app.get('/api/projects/:projectId/materials/daily', (req, res, next) => {
  requireAuth(req, res, async () => {
    const projectId = req.params.projectId;
    const userId = req.userId || req.user?.id;
    if (!userId) {
      return res.status(401).json({ success: false, error: 'Not authenticated' });
    }
    try {
      const supabaseUrl = process.env.SUPABASE_URL;
      const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
      if (!supabaseUrl || !supabaseServiceKey) {
        return res.status(500).json({ success: false, error: 'Server not configured' });
      }
      const { createClient } = await import('@supabase/supabase-js');
      const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

      const allowedDaily = await userHasProjectAccess(supabase, projectId, userId);
      if (!allowedDaily) {
        return res.status(404).json({ success: false, error: 'Project not found' });
      }

      const dateParam = req.query.date;
      const dateStr = dateParam ? String(dateParam).substring(0, 10) : null;

      if (dateStr && /^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
        const dayStart = `${dateStr}T00:00:00.000Z`;
        const dayEnd = `${dateStr}T23:59:59.999Z`;
        const { data: txs, error: txErr } = await supabase
          .from('material_transactions')
          .select('id, material_id, quantity, transaction_type, description, source, created_at')
          .eq('project_id', projectId)
          .gte('created_at', dayStart)
          .lte('created_at', dayEnd)
          .order('created_at', { ascending: false });
        if (txErr) {
          console.error('[materials/daily GET date]', txErr.message);
          if (txErr.code === '42P01' || /material_transactions/i.test(txErr.message)) {
            return res.json({ success: true, date: dateStr, entries: [] });
          }
          return res.status(500).json({ success: false, error: txErr.message || 'Failed to load day' });
        }
        const ids = [...new Set((txs || []).map((t) => t.material_id).filter(Boolean))];
        let nameById = {};
        if (ids.length > 0) {
          const { data: inv } = await supabase.from('materials_inventory').select('id, name, unit').in('id', ids);
          (inv || []).forEach((r) => {
            nameById[r.id] = r;
          });
        }
        const entries = (txs || []).map((t) => {
          const inv = nameById[t.material_id];
          return {
            id: t.id,
            material_name: inv?.name || 'Unknown',
            unit: inv?.unit || 'units',
            quantity: parseFloat(String(t.quantity || 0)),
            transaction_type: t.transaction_type,
            description: t.description,
            source: t.source,
            created_at: t.created_at,
          };
        });
        return res.json({ success: true, date: dateStr, entries });
      }

      const last60 = [];
      for (let i = 59; i >= 0; i--) {
        const d = new Date();
        d.setUTCDate(d.getUTCDate() - i);
        last60.push(d.toISOString().split('T')[0]);
      }
      const sixtyDaysAgo = new Date();
      sixtyDaysAgo.setUTCDate(sixtyDaysAgo.getUTCDate() - 59);
      sixtyDaysAgo.setUTCHours(0, 0, 0, 0);

      const { data: txRows, error: heatErr } = await supabase
        .from('material_transactions')
        .select('created_at')
        .eq('project_id', projectId)
        .gte('created_at', sixtyDaysAgo.toISOString());
      if (heatErr) {
        console.error('[materials/daily GET heatmap]', heatErr.message);
        if (heatErr.code === '42P01' || /material_transactions/i.test(heatErr.message)) {
          const heatmap = last60.map((date) => ({ date, active: false, entryCount: 0 }));
          return res.json({
            success: true,
            heatmap,
            stats: {
              totalDaysWithMaterials: 0,
              currentStreak: 0,
              todayLogged: false,
              todayEntryCount: 0,
            },
          });
        }
        return res.status(500).json({ success: false, error: heatErr.message || 'Failed to load materials calendar' });
      }

      const countByDate = {};
      for (const t of txRows || []) {
        if (!t.created_at) continue;
        const k = utcDateKeyFromIso(t.created_at);
        countByDate[k] = (countByDate[k] || 0) + 1;
      }
      const heatmap = last60.map((date) => ({
        date,
        active: (countByDate[date] || 0) > 0,
        entryCount: countByDate[date] || 0,
      }));

      const since400 = new Date();
      since400.setUTCDate(since400.getUTCDate() - 400);
      const { data: streakTx } = await supabase
        .from('material_transactions')
        .select('created_at')
        .eq('project_id', projectId)
        .gte('created_at', since400.toISOString());
      const dateSet = new Set();
      for (const t of streakTx || []) {
        if (t.created_at) dateSet.add(utcDateKeyFromIso(t.created_at));
      }
      let currentStreak = 0;
      for (let i = 0; i < 366; i++) {
        const expected = new Date();
        expected.setUTCDate(expected.getUTCDate() - i);
        const expectedStr = expected.toISOString().split('T')[0];
        if (dateSet.has(expectedStr)) currentStreak++;
        else break;
      }

      const { data: allForCount } = await supabase
        .from('material_transactions')
        .select('created_at')
        .eq('project_id', projectId)
        .limit(8000);
      const allDates = new Set();
      for (const t of allForCount || []) {
        if (t.created_at) allDates.add(utcDateKeyFromIso(t.created_at));
      }
      const totalDaysWithMaterials = allDates.size;

      const todayStr = new Date().toISOString().split('T')[0];
      const todayCount = countByDate[todayStr] || 0;

      return res.json({
        success: true,
        heatmap,
        stats: {
          totalDaysWithMaterials,
          currentStreak,
          todayLogged: todayCount > 0,
          todayEntryCount: todayCount,
        },
      });
    } catch (err) {
      console.error('[materials/daily GET]', err?.message, err?.stack);
      return res.status(500).json({ success: false, error: err?.message || 'Failed to load materials calendar' });
    }
  });
});

// POST /api/projects/:projectId/materials/daily — Vercel (log_date + entries[])
app.post('/api/projects/:projectId/materials/daily', requireAuth, async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const userId = req.userId || req.user?.id;
    if (!userId) return res.status(401).json({ success: false, error: 'Not authenticated' });
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, error: 'Server not configured' });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

    const allowedPostDaily = await userHasProjectAccess(supabase, projectId, userId);
    if (!allowedPostDaily) return res.status(404).json({ success: false, error: 'Project not found' });

    const { log_date, entries } = req.body || {};
    const logDate = String(log_date || new Date().toISOString().split('T')[0]).substring(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(logDate)) {
      return res.status(400).json({ success: false, error: 'Invalid log_date' });
    }
    const createdAtIso = new Date(`${logDate}T12:00:00.000Z`).toISOString();
    const list = Array.isArray(entries) ? entries : [];
    if (list.length === 0) {
      return res.status(400).json({ success: false, error: 'Add at least one material line' });
    }

    const now = new Date().toISOString();
    let saved = 0;

    const { data: invRowsRaw } = await supabase
      .from('materials_inventory')
      .select('id, name, quantity, unit_cost, total_cost, unit')
      .eq('project_id', projectId);
    const invRows = invRowsRaw || [];
    const invNorm = (n) => normalizeMaterialStorageName(n);
    const findMatches = (canonical) => invRows.filter((r) => invNorm(r.name) === canonical);

    for (const raw of list) {
      const nameRaw = typeof raw.name === 'string' ? raw.name.trim() : '';
      const canonical = normalizeMaterialStorageName(nameRaw);
      const qty = parseFloat(String(raw.quantity ?? '').replace(/,/g, ''));
      if (!canonical || !Number.isFinite(qty) || qty <= 0) continue;
      const unit = String(raw.unit || 'units').trim() || 'units';
      const t = String(raw.transaction_type || 'purchase').toLowerCase();
      const transactionType = t === 'usage' ? 'usage' : 'purchase';

      if (transactionType === 'purchase') {
        const matches = findMatches(canonical);
        const existing = matches.find((r) => r.name === canonical) || matches[0];

        let materialId;
        if (existing) {
          const newQty = parseFloat(String(existing.quantity || 0)) + qty;
          const uc = parseFloat(String(existing.unit_cost || 0));
          const newTotalCost = parseFloat(String(existing.total_cost || 0)) + qty * uc;
          await supabase
            .from('materials_inventory')
            .update({
              name: canonical,
              quantity: newQty,
              total_cost: newTotalCost,
              last_purchased_at: createdAtIso,
              updated_at: now,
              user_id: userId,
            })
            .eq('id', existing.id);
          existing.name = canonical;
          existing.quantity = newQty;
          existing.total_cost = newTotalCost;
          materialId = existing.id;
          await supabase.from('material_transactions').insert({
            material_id: materialId,
            project_id: projectId,
            user_id: userId,
            transaction_type: 'purchase',
            quantity: qty,
            unit_cost: uc,
            total_cost: qty * uc,
            description: `Received ${qty} ${unit} of ${nameRaw}`,
            source: 'dashboard',
            created_at: createdAtIso,
          });
        } else {
          const { data: inserted, error: insErr } = await supabase
            .from('materials_inventory')
            .insert({
              project_id: projectId,
              user_id: userId,
              name: canonical,
              quantity: qty,
              unit,
              unit_cost: 0,
              total_cost: 0,
              source: 'dashboard',
              last_purchased_at: createdAtIso,
              updated_at: now,
            })
            .select('id')
            .single();
          if (insErr || !inserted?.id) continue;
          materialId = inserted.id;
          invRows.push({
            id: inserted.id,
            name: canonical,
            quantity: qty,
            unit_cost: 0,
            total_cost: 0,
            unit,
          });
          await supabase.from('material_transactions').insert({
            material_id: materialId,
            project_id: projectId,
            user_id: userId,
            transaction_type: 'purchase',
            quantity: qty,
            unit_cost: 0,
            total_cost: 0,
            description: `Received ${qty} ${unit} of ${nameRaw}`,
            source: 'dashboard',
            created_at: createdAtIso,
          });
        }
        saved++;
      } else {
        const matches = findMatches(canonical).sort((a, b) => String(a.id).localeCompare(String(b.id)));
        if (matches.length === 0) {
          return res.status(400).json({
            success: false,
            error: `No inventory match for "${nameRaw}". Log a purchase first or check spelling.`,
          });
        }
        const usedQty = qty;
        const totalAvail = matches.reduce((s, r) => s + parseFloat(String(r.quantity || 0)), 0);
        if (totalAvail < usedQty) {
          return res.status(400).json({
            success: false,
            error: `Not enough stock for "${nameRaw}" (have ${totalAvail}, need ${usedQty}).`,
          });
        }
        let remaining = usedQty;
        for (const row of matches) {
          if (remaining <= 0) break;
          const q = parseFloat(String(row.quantity || 0));
          if (q <= 0) continue;
          const take = Math.min(q, remaining);
          const newQty = q - take;
          await supabase
            .from('materials_inventory')
            .update({
              quantity: newQty,
              last_used_at: createdAtIso,
              updated_at: now,
              user_id: userId,
            })
            .eq('id', row.id);
          row.quantity = newQty;
          remaining -= take;
        }
        await supabase.from('material_transactions').insert({
          material_id: matches[0].id,
          project_id: projectId,
          user_id: userId,
          transaction_type: 'usage',
          quantity: -usedQty,
          unit_cost: 0,
          total_cost: 0,
          description: `Used ${usedQty} ${unit} of ${nameRaw}`,
          source: 'dashboard',
          created_at: createdAtIso,
        });
        saved++;
      }
    }

    if (saved === 0) {
      return res.status(400).json({ success: false, error: 'No valid entries to save' });
    }
    return res.status(201).json({ success: true, saved, log_date: logDate });
  } catch (err) {
    console.error('[materials/daily POST]', err?.message, err?.stack);
    return res.status(500).json({ success: false, error: err?.message || 'Failed to save material log' });
  }
});

// POST /api/projects/:projectId/materials — Add or upsert material (match on project_id + name)
app.post('/api/projects/:projectId/materials', requireAuth, async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const userId = req.userId || req.user?.id;
    if (!userId) return res.status(401).json({ success: false, error: 'Not authenticated' });
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, error: 'Server not configured' });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

    const allowedPostMat = await userHasProjectAccess(supabase, projectId, userId);
    if (!allowedPostMat) return res.status(404).json({ success: false, error: 'Project not found' });

    const { name, quantity, unit, unit_cost, total_cost, source, low_stock_threshold } = req.body || {};
    const nameStr = typeof name === 'string' ? name.trim() : '';
    if (!nameStr) return res.status(400).json({ success: false, error: 'name is required' });
    const canonical = normalizeMaterialStorageName(nameStr);
    if (!canonical) return res.status(400).json({ success: false, error: 'name is required' });
    const qty = parseFloat(String(quantity ?? 0)) || 0;
    const unitCost = unit_cost != null ? parseFloat(String(unit_cost)) : 0;
    const totalCost = total_cost != null ? parseFloat(String(total_cost)) : qty * unitCost;
    const sourceStr = source === 'whatsapp' || source === 'dashboard' ? source : 'manual';
    const lowTh =
      low_stock_threshold != null && low_stock_threshold !== ''
        ? parseFloat(String(low_stock_threshold))
        : null;
    const now = new Date().toISOString();

    const { data: invList } = await supabase
      .from('materials_inventory')
      .select('id, name, quantity, unit_cost, total_cost')
      .eq('project_id', projectId);
    const rows = invList || [];
    const matches = rows.filter((r) => normalizeMaterialStorageName(r.name) === canonical);
    const existing = matches.find((r) => r.name === canonical) || matches[0];

    let materialId;
    if (existing) {
      const newQty = parseFloat(String(existing.quantity || 0)) + qty;
      const newTotalCost = parseFloat(String(existing.total_cost || 0)) + totalCost;
      const updatePayload = {
        name: canonical,
        quantity: newQty,
        unit_cost: unitCost || parseFloat(String(existing.unit_cost || 0)),
        total_cost: newTotalCost,
        last_purchased_at: now,
        updated_at: now,
      };
      if (lowTh != null && Number.isFinite(lowTh)) updatePayload.low_stock_threshold = lowTh;
      const { data: updated, error: updateErr } = await supabase
        .from('materials_inventory')
        .update(updatePayload)
        .eq('id', existing.id)
        .select('id')
        .single();
      if (updateErr) {
        console.error('[Materials POST update]', updateErr.message);
        return res.status(500).json({ success: false, error: updateErr.message });
      }
      materialId = updated?.id ?? existing.id;
    } else {
      const insertPayload = {
        project_id: projectId,
        user_id: userId,
        name: canonical,
        quantity: qty,
        unit: unit || 'units',
        unit_cost: unitCost,
        total_cost: totalCost,
        source: sourceStr,
        last_purchased_at: now,
        updated_at: now,
      };
      if (lowTh != null && Number.isFinite(lowTh)) insertPayload.low_stock_threshold = lowTh;
      const { data: inserted, error: insertErr } = await supabase
        .from('materials_inventory')
        .insert(insertPayload)
        .select('id')
        .single();
      if (insertErr) {
        console.error('[Materials POST insert]', insertErr.message);
        return res.status(500).json({ success: false, error: insertErr.message });
      }
      materialId = inserted?.id;
    }

    if (materialId) {
      await supabase.from('material_transactions').insert({
        material_id: materialId,
        project_id: projectId,
        user_id: userId,
        transaction_type: 'purchase',
        quantity: qty,
        unit_cost: unitCost,
        total_cost: totalCost,
        description: `Added ${qty} ${unit || 'units'} of ${nameStr}`,
        source: sourceStr,
      });
    }

    return res.status(201).json({ success: true, id: materialId });
  } catch (err) {
    console.error('[Materials POST]', err.message, err.stack);
    return res.status(500).json({ success: false, error: err.message || 'Failed to save material' });
  }
});

// PATCH /api/projects/:projectId/materials/:id — Update material quantity/costs
app.patch('/api/projects/:projectId/materials/:id', requireAuth, async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const materialId = req.params.id;
    const userId = req.userId || req.user?.id;
    if (!userId) return res.status(401).json({ success: false, error: 'Not authenticated' });
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, error: 'Server not configured' });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

    const { data: row } = await supabase
      .from('materials_inventory')
      .select('id, project_id, user_id')
      .eq('id', materialId)
      .eq('project_id', projectId)
      .maybeSingle();
    if (!row) return res.status(404).json({ success: false, error: 'Material not found' });
    const allowedPatchMat = await userHasProjectAccess(supabase, projectId, userId);
    if (!allowedPatchMat) return res.status(403).json({ success: false, error: 'Not allowed' });

    const { quantity, unit, unit_cost, total_cost, low_stock_threshold } = req.body || {};
    const updates = { updated_at: new Date().toISOString() };
    if (quantity != null) updates.quantity = parseFloat(String(quantity));
    if (typeof unit === 'string' && unit.trim()) updates.unit = unit.trim();
    if (unit_cost != null) updates.unit_cost = parseFloat(String(unit_cost));
    if (total_cost != null) updates.total_cost = parseFloat(String(total_cost));
    if (low_stock_threshold != null) updates.low_stock_threshold = parseFloat(String(low_stock_threshold));

    const { data: updated, error: updateErr } = await supabase
      .from('materials_inventory')
      .update(updates)
      .eq('id', materialId)
      .eq('project_id', projectId)
      .select()
      .single();
    if (updateErr) {
      console.error('[Materials PATCH]', updateErr.message);
      return res.status(500).json({ success: false, error: updateErr.message });
    }

    await supabase.from('material_transactions').insert({
      material_id: materialId,
      project_id: projectId,
      user_id: userId,
      transaction_type: 'adjustment',
      quantity: updates.quantity ?? 0,
      unit_cost: updates.unit_cost ?? 0,
      total_cost: updates.total_cost ?? 0,
      description: 'Updated via dashboard',
      source: 'dashboard',
    });

    return res.json({ success: true, material: updated });
  } catch (err) {
    console.error('[Materials PATCH]', err.message, err.stack);
    return res.status(500).json({ success: false, error: err.message || 'Failed to update material' });
  }
});

// DELETE /api/projects/:projectId/materials/:id
app.delete('/api/projects/:projectId/materials/:id', requireAuth, async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const materialId = req.params.id;
    const userId = req.userId || req.user?.id;
    if (!userId) return res.status(401).json({ success: false, error: 'Not authenticated' });
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, error: 'Server not configured' });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

    const allowedDelMat = await userHasProjectAccess(supabase, projectId, userId);
    if (!allowedDelMat) return res.status(404).json({ success: false, error: 'Project not found' });

    const { data: row, error: delErr } = await supabase
      .from('materials_inventory')
      .delete()
      .eq('id', materialId)
      .eq('project_id', projectId)
      .select('id')
      .single();
    if (delErr || !row) {
      return res.status(404).json({ success: false, error: 'Material not found or already deleted' });
    }
    return res.status(200).json({ success: true });
  } catch (err) {
    console.error('[Materials DELETE]', err.message, err.stack);
    return res.status(500).json({ success: false, error: err.message || 'Failed to delete material' });
  }
});

// GET /api/projects/:projectId/daily — Daily Accountability page
app.get('/api/projects/:projectId/daily', (req, res, next) => {
  requireAuth(req, res, async () => {
    const projectId = req.params.projectId;
    const userId = req.userId || req.user?.id;
    if (!userId) {
      return res.status(401).json({ success: false, error: 'Not authenticated' });
    }
    try {
      const supabaseUrl = process.env.SUPABASE_URL;
      const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
      if (!supabaseUrl || !supabaseServiceKey) {
        return res.status(500).json({ success: false, error: 'Server not configured' });
      }
      const { createClient } = await import('@supabase/supabase-js');
      const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

      const { data: projectRow, error: projectError } = await supabase
        .from('projects')
        .select('id')
        .eq('id', projectId)
        .eq('user_id', userId)
        .maybeSingle();
      if (projectError || !projectRow) {
        return res.status(404).json({ success: false, error: 'Project not found' });
      }

      // Fetch all logs for this project with activity_entries
      const { data: logRows, error } = await supabase
        .from('daily_logs')
        .select('id, log_date, worker_count, notes, milestones, milestone_count, weather_condition, photo_urls, activity_entries, created_at')
        .eq('project_id', projectId)
        .order('log_date', { ascending: false })
        .limit(60);

      if (error) {
        console.error('[Daily]', error);
        return res.status(500).json({ success: false, error: error.message });
      }

      const logs = logRows || [];
      const todayStr = new Date().toISOString().split('T')[0];
      const todayLog = logs.find((l) => (l.log_date || '').toString().substring(0, 10) === todayStr);

      // Generate last 60 days for heatmap
      const last60Dates = [];
      for (let i = 59; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        last60Dates.push(d.toISOString().split('T')[0]);
      }

      const logByDate = {};
      for (const l of logs) {
        const d = (l.log_date || '').toString().substring(0, 10);
        if (d) logByDate[d] = l;
      }

      // Heatmap with entry counts for color intensity
      const heatmap = last60Dates.map((date) => {
        const log = logByDate[date];
        const entries = log?.activity_entries || [];
        const entryCount = Array.isArray(entries) ? entries.length : 0;
        return {
          date,
          active: !!log,
          entryCount,
          workerCount: log ? (log.worker_count || 0) : 0,
          hasNotes: !!(log && log.notes),
        };
      });

      // Recent logs with entries
      const recentLogs = logs.slice(0, 10).map((l) => {
        const raw = l.photo_urls;
        const photoEntries = normalizePhotoUrls(raw);
        const photoUrls = photoEntries.map((p) => p.url);
        return {
          id: l.id,
          log_date: l.log_date,
          worker_count: l.worker_count,
          notes: l.notes,
          milestones: l.milestones,
          milestone_count: l.milestone_count,
          weather_condition: l.weather_condition,
          photo_urls: photoUrls,
          photo_entries: photoEntries,
          activity_entries: l.activity_entries || [],
          created_at: l.created_at,
        };
      });

      // Calculate total photos from both photo_urls and activity_entries
      let totalPhotos = 0;
      let totalPhotoEntries = 0;
      logs.forEach((l) => {
        // Photos in photo_urls
        const urls = normalizePhotoUrls(l.photo_urls);
        totalPhotos += urls.length;
        
        // Photos in activity_entries
        const entries = l.activity_entries || [];
        if (Array.isArray(entries)) {
          entries.forEach((e) => {
            if (e.activity_type === 'photo' || e.photo_urls) {
              totalPhotoEntries++;
            }
          });
        }
      });

      // Calculate avg workers from both worker_count field and labor entries
      const workerCounts = [];
      logs.forEach((l) => {
        // Direct worker_count
        if (l.worker_count != null && l.worker_count > 0) {
          workerCounts.push(l.worker_count);
        }
        // Workers from activity entries
        const entries = l.activity_entries || [];
        if (Array.isArray(entries)) {
          entries.forEach((e) => {
            if (e.activity_type === 'labor' && e.worker_count) {
              workerCounts.push(e.worker_count);
            }
          });
        }
      });
      const avgWorkerCount = workerCounts.length > 0 ? workerCounts.reduce((a, b) => a + b, 0) / workerCounts.length : 0;

      // This week active (Mon-Sun)
      const now = new Date();
      const startOfWeek = new Date(now);
      startOfWeek.setDate(now.getDate() - now.getDay() + (now.getDay() === 0 ? -6 : 1)); // Monday
      startOfWeek.setHours(0, 0, 0, 0);
      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(startOfWeek.getDate() + 6); // Sunday
      
      const thisWeekActive = logs.filter((l) => {
        const d = new Date(l.log_date + 'T12:00:00');
        return d >= startOfWeek && d <= endOfWeek;
      }).length;

      // Current streak (consecutive days ending today)
      let currentStreak = 0;
      const sortedDates = [...new Set(logs.map((l) => (l.log_date || '').toString().substring(0, 10)))].sort().reverse();
      const hasEntryToday = sortedDates.includes(todayStr);
      
      if (hasEntryToday || sortedDates.length > 0) {
        for (let i = 0; i < (hasEntryToday ? sortedDates.length : 0); i++) {
          const expected = new Date();
          expected.setDate(expected.getDate() - i);
          const expectedStr = expected.toISOString().split('T')[0];
          if (sortedDates[i] === expectedStr) currentStreak++;
          else break;
        }
      }

      // Stats
      const stats = {
        totalActiveDays: logs.length,
        currentStreak,
        avgWorkerCount: Math.round(avgWorkerCount * 10) / 10,
        totalPhotos: totalPhotos + totalPhotoEntries,
        thisWeekActive,
      };

      const today = {
        active: !!todayLog,
        workerCount: todayLog ? (todayLog.worker_count || 0) : 0,
        notes: todayLog ? (todayLog.notes || '') : '',
        photos: todayLog
          ? (() => {
              const raw = todayLog.photo_urls;
              const arr = Array.isArray(raw) ? raw : raw ? [raw] : [];
              return arr.map((e) => (typeof e === 'string' ? e : e?.url)).filter(Boolean);
            })()
          : [],
      };

      return res.json({
        success: true,
        heatmap,
        recentLogs,
        stats,
        today,
      });
    } catch (err) {
      console.error('[Daily API Error]', err.message, err.stack);
      return res.status(500).json({ success: false, error: err.message || 'Failed to load daily logs' });
    }
  });
});

// GET /api/projects/:projectId/trends — Trends & Insights page
app.get('/api/projects/:projectId/trends', (req, res, next) => {
  requireAuth(req, res, async () => {
    const projectId = req.params.projectId;
    const userId = req.userId || req.user?.id;
    if (!userId) {
      return res.status(401).json({ success: false, error: 'Not authenticated' });
    }
    try {
      const supabaseUrl = process.env.SUPABASE_URL;
      const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
      if (!supabaseUrl || !supabaseServiceKey) {
        return res.status(500).json({ success: false, error: 'Server not configured' });
      }
      const { createClient } = await import('@supabase/supabase-js');
      const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

      const { data: projectRow, error: projectError } = await supabase
        .from('projects')
        .select('id, budget')
        .eq('id', projectId)
        .or(`user_id.eq.${userId},manager_id.eq.${userId}`)
        .maybeSingle();
      if (projectError || !projectRow) {
        return res.status(404).json({ success: false, error: 'Project not found' });
      }

      const budgetTotal = parseFloat(String(projectRow.budget || 0));

      const { data: expenseRows } = await supabase
        .from('expenses')
        .select('amount, expense_date, created_at')
        .eq('project_id', projectId)
        .is('deleted_at', null);

      const { data: logRows } = await supabase
        .from('daily_logs')
        .select('log_date, worker_count')
        .eq('project_id', projectId)
        .order('log_date', { ascending: false })
        .limit(90);

      const { data: materialRows } = await supabase
        .from('materials_inventory')
        .select('name, quantity, unit, unit_cost, low_stock_threshold')
        .eq('project_id', projectId)
        .order('quantity', { ascending: false })
        .limit(20);

      const { data: vendorRows } = await supabase
        .from('vendors')
        .select('name, total_spent')
        .eq('project_id', projectId)
        .order('total_spent', { ascending: false })
        .limit(5);

      const expenses = expenseRows || [];
      const logs = logRows || [];
      const materials = materialRows || [];
      const vendorList = vendorRows || [];

      const totalSpent = expenses.reduce((s, e) => s + parseFloat(String(e.amount || 0)), 0);
      const remaining = Math.max(0, budgetTotal - totalSpent);

      const weeklyBurnRate = computeWeeklyBurnRate(expenses, totalSpent);
      const weeksRemaining = weeklyBurnRate > 0 ? Math.floor(remaining / weeklyBurnRate) : null;
      const budgetRunout = weeksRemaining != null && weeksRemaining < 9999
        ? new Date(Date.now() + weeksRemaining * 7 * 86400000).toISOString().split('T')[0]
        : null;

      const byMonthMap = {};
      for (const e of expenses) {
        const d = e.expense_date || e.created_at;
        const dateStr = typeof d === 'string' ? d.split('T')[0] : (d ? new Date(d).toISOString().split('T')[0] : null);
        if (!dateStr) continue;
        const monthKey = dateStr.substring(0, 7);
        const label = new Date(monthKey + '-01T12:00:00').toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
        if (!byMonthMap[monthKey]) byMonthMap[monthKey] = { month: label, amount: 0, sortKey: monthKey };
        byMonthMap[monthKey].amount += parseFloat(String(e.amount || 0));
      }
      const byMonth = Object.values(byMonthMap).sort((a, b) => a.sortKey.localeCompare(b.sortKey)).map(({ month, amount }) => ({ month, amount }));

      const last3Months = byMonth.slice(-3);
      const spendingTrend = last3Months.length < 2 ? 'stable'
        : last3Months[last3Months.length - 1].amount > last3Months[last3Months.length - 2].amount ? 'increasing'
        : last3Months[last3Months.length - 1].amount < last3Months[last3Months.length - 2].amount ? 'decreasing'
        : 'stable';

      const byDay = logs.map((l) => ({
        date: l.log_date,
        count: l.worker_count || 0,
      })).slice(0, 30);
      const workerCounts = logs.filter((l) => l.worker_count != null && l.worker_count > 0).map((l) => l.worker_count);
      const workerAvg = workerCounts.length > 0 ? workerCounts.reduce((a, b) => a + b, 0) / workerCounts.length : 0;
      const workerPeak = workerCounts.length > 0 ? Math.max(...workerCounts) : 0;
      const workersTrend = byDay.length < 2 ? 'stable'
        : (byDay[byDay.length - 1]?.count || 0) > (byDay[byDay.length - 2]?.count || 0) ? 'increasing'
        : (byDay[byDay.length - 1]?.count || 0) < (byDay[byDay.length - 2]?.count || 0) ? 'decreasing'
        : 'stable';

      const mostUsed = materials.slice(0, 5).map((m) => ({
        name: m.name || '',
        quantity: parseFloat(String(m.quantity || 0)),
        unit: m.unit || 'units',
        unitCost: parseFloat(String(m.unit_cost || 0)),
        currentValue: parseFloat(String(m.quantity || 0)) * parseFloat(String(m.unit_cost || 0)),
      }));

      const topVendors = vendorList.map((v) => ({
        name: v.name || '',
        total: parseFloat(String(v.total_spent || 0)),
      }));

      const alerts = [];
      if (budgetTotal > 0 && (totalSpent / budgetTotal) > 0.8) {
        alerts.push({ type: 'budget_warning', message: 'Over 80% of budget used', severity: 'high', date: new Date().toISOString().split('T')[0] });
      }
      const lowStockMaterials = materials.filter((m) => {
        const th = m.low_stock_threshold != null ? parseFloat(String(m.low_stock_threshold)) : 5;
        return parseFloat(String(m.quantity || 0)) <= th;
      });
      for (const m of lowStockMaterials) {
        alerts.push({ type: 'low_stock', message: `${m.name} low on stock (${m.quantity} ${m.unit})`, severity: 'medium', date: new Date().toISOString().split('T')[0] });
      }

      return res.json({
        success: true,
        spending: {
          byMonth,
          byWeek: [],
          trend: spendingTrend,
          projectedCompletion: null,
        },
        workers: {
          byDay,
          average: Math.round(workerAvg * 10) / 10,
          peak: workerPeak,
          trend: workersTrend,
        },
        materials: {
          mostUsed,
          topVendors,
        },
        alerts,
        predictions: {
          estimatedCompletion: null,
          budgetRunout,
          weeklyBurnRate: Math.round(weeklyBurnRate * 100) / 100,
        },
      });
    } catch (err) {
      console.error('[Trends API Error]', err.message, err.stack);
      return res.status(500).json({ success: false, error: err.message || 'Failed to load trends' });
    }
  });
});

// ============================================================================
// TEST ENDPOINTS (available even when server app is loaded)
// ============================================================================

// Debug Auth Endpoint (JWT only — no session).
// SECURITY: Disabled in production to avoid leaking JWT_SECRET_SET / NODE_ENV
// and the decoded userId of whoever can forge tokens.
app.get('/api/debug/session', async (req, res) => {
  if (process.env.NODE_ENV === 'production' && process.env.ENABLE_DEBUG_ENDPOINTS !== '1') {
    return res.status(404).json({ success: false, error: 'Not found' });
  }
  try {
    const token = extractToken(req);
    const decoded = token ? verifyToken(token) : null;
    res.json({
      success: true,
      auth: 'JWT only (no session)',
      userId: decoded?.userId || null,
      env: {
        JWT_SECRET_SET: !!process.env.JWT_SECRET,
        NODE_ENV: process.env.NODE_ENV,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Auth check failed',
      details: error.message
    });
  }
});

// WhatsApp Debug Endpoint (always available - BEFORE server app mounts).
// SECURITY: Disabled in production to avoid exposing webhook/inbound logs.
app.get('/webhook/debug', async (req, res) => {
  if (process.env.NODE_ENV === 'production' && process.env.ENABLE_DEBUG_ENDPOINTS !== '1') {
    return res.status(404).json({ success: false, error: 'Not found' });
  }
  try {
    const limit = parseInt(req.query.limit) || 50;
    
    res.json({
      success: true,
      total: 0,
      logs: [],
      message: 'WhatsApp debug endpoint reached (fallback mode - logs not available)',
      limit,
      note: 'If compiled server loads, this will show actual WhatsApp logs'
    });
  } catch (error) {
    console.error('[WhatsApp Debug] Error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// ============================================================================
// AUTHENTICATION ENDPOINTS (always available - BEFORE server app mounts)
// ============================================================================

// Middleware to check authentication (JWT only — no session)
function requireAuth(req, res, next) {
  const token = extractToken(req);
  if (!token) {
    return res.status(401).json({
      success: false,
      error: 'Not authenticated',
      message: 'Please log in to access this resource',
    });
  }
    const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({
      success: false,
      error: 'Invalid or expired token',
      message: 'Please log in again',
    });
  }
      req.userId = decoded.userId;
      req.userEmail = decoded.email;
      req.user = { id: decoded.userId };
      return next();
}

// POST /api/auth/login - Login user with Supabase Auth
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log('[Login] Attempt:', email);
    
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Email and password are required',
      });
    }

    // Initialize Supabase client for authentication
    const { createClient } = await import('@supabase/supabase-js');
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseAnonKey = process.env.SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseAnonKey) {
      console.error('[Login] ❌ Missing Supabase credentials');
      return res.status(500).json({
        success: false,
        error: 'Server configuration error',
        message: 'SUPABASE_URL and SUPABASE_ANON_KEY must be configured',
      });
    }

    // Create auth client with anon key for user authentication
    const authClient = createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    // Sign in with Supabase Auth
    console.log('[Login] Attempting Supabase sign in...');
    const { data: authData, error: authError } = await authClient.auth.signInWithPassword({
      email,
      password,
    });

    if (authError || !authData.user) {
      console.error('[Login] ❌ Supabase Auth error:', authError?.message);
      return res.status(401).json({
        success: false,
        error: 'Invalid credentials',
        message: authError?.message || 'Authentication failed',
      });
    }

    console.log('[Login] ✅ Supabase Auth successful:', authData.user.id);

    // Get or create profile from Supabase profiles table (no Drizzle/Postgres)
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseServiceKey) {
      console.error('[Login] ❌ SUPABASE_SERVICE_ROLE_KEY not set');
      return res.status(500).json({
        success: false,
        error: 'Server configuration error',
        message: 'SUPABASE_SERVICE_ROLE_KEY must be configured',
      });
    }
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

    const { data: profile, error: profileError } = await supabaseAdmin
      .from('profiles')
      .select('id, email, full_name, whatsapp_number')
      .eq('id', authData.user.id)
      .maybeSingle();

    if (profileError) {
      console.error('[Login] ❌ Profile fetch error:', profileError.message);
      return res.status(500).json({
        success: false,
        error: 'Failed to load profile',
        message: profileError.message,
      });
    }

    let userProfile = profile;
    if (!userProfile) {
      const fullName = authData.user.user_metadata?.full_name || authData.user.email?.split('@')[0] || 'User';
      const whatsappNumber = (authData.user.user_metadata?.whatsapp_number || '').trim() || ('pending-' + authData.user.id.substring(0, 8));
      const { data: inserted, error: insertErr } = await supabaseAdmin
        .from('profiles')
        .upsert(
          {
            id: authData.user.id,
            email: authData.user.email,
            full_name: fullName,
            whatsapp_number: whatsappNumber,
          },
          { onConflict: 'id' }
        )
        .select('id, email, full_name, whatsapp_number')
        .single();
      if (insertErr || !inserted) {
        console.error('[Login] ❌ Profile upsert error:', insertErr?.message);
        return res.status(500).json({
          success: false,
          error: 'Failed to create profile',
          message: insertErr?.message || 'Please contact support',
        });
      }
      userProfile = inserted;
      console.log('[Login] ✅ Profile created in profiles table');
    }

    // Merge WhatsApp-only orphan profiles: same whatsapp_number but different profile id (created by bot before dashboard signup)
    const dashWhatsApp = (userProfile.whatsapp_number || '').trim();
    const isPendingNumber = !dashWhatsApp || dashWhatsApp.startsWith('pending-') || /^pending-/i.test(dashWhatsApp);
    if (dashWhatsApp && !isPendingNumber) {
      const { data: orphanProfiles, error: orphanErr } = await supabaseAdmin
        .from('profiles')
        .select('id')
        .eq('whatsapp_number', dashWhatsApp)
        .neq('id', authData.user.id);

      if (!orphanErr && orphanProfiles && orphanProfiles.length > 0) {
        for (const orphan of orphanProfiles) {
          const orphanId = orphan.id;
          const { error: updateProjErr } = await supabaseAdmin
            .from('projects')
            .update({ user_id: authData.user.id })
            .eq('user_id', orphanId);
          if (updateProjErr) console.error('[Login] Merge projects error:', updateProjErr.message);

          const { error: updateExpErr } = await supabaseAdmin
            .from('expenses')
            .update({ user_id: authData.user.id })
            .eq('user_id', orphanId);
          if (updateExpErr) console.error('[Login] Merge expenses error:', updateExpErr.message);

          await supabaseAdmin.from('projects').update({ manager_id: null }).eq('manager_id', orphanId);
          await supabaseAdmin.from('profiles').delete().eq('id', orphanId);
          console.log('[Login] ✅ Merged WhatsApp profile', orphanId, '→', authData.user.id);
        }
      }
    }

    // Generate JWT token (client stores it and sends via Authorization header)
    const token = generateToken(authData.user.id, userProfile.email || authData.user.email);

    return res.json({
      success: true,
      token,
      user: {
        id: userProfile.id,
        email: userProfile.email || authData.user.email,
        fullName: userProfile.full_name,
        whatsappNumber: userProfile.whatsapp_number,
      },
    });
  } catch (error) {
    console.error('[Login] ❌ Unexpected error:', error);
    console.error('[Login] ❌ Error stack:', error.stack);
    res.status(500).json({
      success: false,
      error: 'Login failed',
      message: error.message || 'An unexpected error occurred',
      details: process.env.NODE_ENV === 'development' ? error.stack : undefined,
    });
  }
});

// POST /api/auth/register - Register new user with Supabase Auth
app.post('/api/auth/register', async (req, res) => {
  try {
    const { fullName, whatsappNumber, email, password } = req.body;
    console.log('[Register] Attempt:', email);

    if (!fullName || !whatsappNumber || !email || !password) {
      return res.status(400).json({
        success: false,
        error: 'All fields are required: fullName, whatsappNumber, email, password',
      });
    }

    // Initialize Supabase client
    const { createClient } = await import('@supabase/supabase-js');
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error('[Register] ❌ Missing Supabase credentials');
      return res.status(500).json({
        success: false,
        error: 'Server configuration error',
        message: 'SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be configured',
      });
    }

    // Create admin client for user creation
    const adminClient = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    // 1. Create user in Supabase Auth
    console.log('[Register] Creating Supabase Auth user...');
    const { data: authData, error: authError } = await adminClient.auth.admin.createUser({
      email,
      password,
      email_confirm: true, // Auto-confirm for MVP
      user_metadata: {
        full_name: fullName,
        whatsapp_number: whatsappNumber,
      },
    });

    if (authError || !authData.user) {
      console.error('[Register] ❌ Supabase Auth error:', authError?.message);
      return res.status(400).json({
        success: false,
        error: authError?.message || 'Failed to create user',
      });
    }

    console.log('[Register] ✅ Supabase Auth user created:', authData.user.id);

    // Create profile in Supabase profiles table (no Drizzle/Postgres)
    const { error: profileError } = await adminClient
      .from('profiles')
      .upsert(
        {
          id: authData.user.id,
          email,
          full_name: fullName,
          whatsapp_number: whatsappNumber,
        },
        { onConflict: 'id' }
      );

    if (profileError) {
      console.error('[Register] ❌ Profile insert error:', profileError.message);
      await adminClient.auth.admin.deleteUser(authData.user.id);
      return res.status(500).json({
        success: false,
        error: 'Failed to create profile',
        message: profileError.message,
      });
    }

    console.log('[Register] ✅ Profile created in profiles table');

    // Generate JWT token
    const token = generateToken(authData.user.id, email);

    console.log('[Register] ✅ Token generated for user:', authData.user.id);

    // Return token and user data
    res.status(201).json({
      success: true,
      token, // JWT token for frontend to store
      user: {
        id: authData.user.id,
        email,
        fullName,
        whatsappNumber,
      },
    });
  } catch (error) {
    console.error('[Register] ❌ Unexpected error:', error);
    res.status(500).json({
      success: false,
      error: 'Registration failed',
      message: error.message || 'An unexpected error occurred',
      details: process.env.NODE_ENV === 'development' ? error.stack : undefined,
    });
  }
});

// GET /api/auth/me - Get current user (using JWT)
app.get('/api/auth/me', requireAuth, async (req, res) => {
  try {
    const userId = req.userId; // Set by requireAuth middleware
    console.log('[Auth Me] User ID from token:', userId);

    if (!userId) {
      return res.status(401).json({
        success: false,
        error: 'Not authenticated',
      });
    }

    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({
        success: false,
        error: 'Server configuration error',
      });
    }

    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('id, email, full_name, whatsapp_number, default_currency, preferred_language')
      .eq('id', userId)
      .maybeSingle();

    if (profileError) {
      console.error('[Auth Me] ❌ Profile error:', profileError.message);
      return res.status(500).json({
        success: false,
        error: 'Failed to fetch user',
      });
    }

    if (!profile) {
      console.log('[Auth Me] ❌ User profile not found');
      return res.status(404).json({
        success: false,
        error: 'User profile not found',
      });
    }

    console.log('[Auth Me] ✅ Success:', profile.id);

    res.json({
      success: true,
      user: {
        id: profile.id,
        email: profile.email || null,
        fullName: profile.full_name,
        whatsappNumber: profile.whatsapp_number,
        defaultCurrency: profile.default_currency || 'UGX',
        preferredLanguage: profile.preferred_language || 'en',
      },
    });
  } catch (error) {
    console.error('[Auth Me] ❌ Error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch user',
      details: error.message,
    });
  }
});

// POST /api/auth/logout - Logout user (JWT - just clear token on frontend)
app.post('/api/auth/logout', (req, res) => {
  console.log('[Logout] Logout requested');
  // With JWT, logout is handled on the frontend by removing the token
  // No server-side action needed
  res.json({
    success: true,
    message: 'Logged out successfully. Please clear token on frontend.',
  });
});

// POST /api/auth/forgot-password - Send password reset email (Supabase Auth)
app.post('/api/auth/forgot-password', async (req, res) => {
  try {
    const { email, redirectTo: bodyRedirect } = req.body || {};
    if (!email || typeof email !== 'string' || !email.trim()) {
      return res.status(400).json({
        success: false,
        error: 'Email is required',
        message: 'Email is required',
      });
    }
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseAnonKey = process.env.SUPABASE_ANON_KEY;
    if (!supabaseUrl || !supabaseAnonKey) {
      console.error('[forgot-password] Supabase URL or ANON_KEY not set');
      return res.status(500).json({
        success: false,
        error: 'Server configuration error',
        message: 'Server configuration error',
      });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseAnonKey, { auth: { persistSession: false } });
    const originHeader = typeof req.headers.origin === 'string' ? req.headers.origin.trim() : '';
    let redirectTo =
      typeof bodyRedirect === 'string' && bodyRedirect.startsWith('http')
        ? bodyRedirect
        : originHeader
          ? `${originHeader.replace(/\/$/, '')}/reset-password`
          : process.env.APP_URL
            ? `${String(process.env.APP_URL).replace(/\/$/, '')}/reset-password`
            : undefined;
    console.log('[forgot-password] redirectTo:', redirectTo);
    console.log('[forgot-password] Sending reset to:', email.trim());
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: redirectTo || undefined,
    });
    if (error) {
      console.error('[forgot-password] Supabase error:', error.message);
      console.error('[forgot-password] Full Supabase error:', JSON.stringify(error));
      return res.status(400).json({
        success: false,
        error: error.message,
        message: error.message,
      });
    }
    // Supabase dashboard: Authentication → Email Templates → ensure "Reset Password" is enabled.
    // Authentication → Settings → "Enable email confirmations" and SMTP. Free tier: 3 emails/hour; custom SMTP may be needed.
    return res.json({
      success: true,
      message: 'Reset link sent',
      emailProvider: 'supabase',
    });
  } catch (err) {
    console.error('[forgot-password] Unexpected error:', err?.message || err, err?.stack || '');
    return res.status(500).json({
      success: false,
      error: 'Server error',
      message: err?.message || 'Server error',
    });
  }
});

/**
 * POST /api/auth/reset-password
 * Client sends access_token from email hash; server decodes JWT sub and uses admin API to set password.
 */
app.post('/api/auth/reset-password', async (req, res) => {
  try {
    const password = req.body?.password;
    const token = req.body?.token;
    if (!password || typeof password !== 'string' || password.length < 6) {
      return res.status(400).json({
        success: false,
        error: 'Validation error',
        message: 'Password must be at least 6 characters.',
      });
    }
    if (!token || typeof token !== 'string') {
      return res.status(400).json({
        success: false,
        error: 'Reset link required',
        message:
          'Please use the link from your password reset email. If it expired, request a new reset from Forgot Password.',
      });
    }
    const supabaseUrl = process.env.SUPABASE_URL;
    const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !serviceKey) {
      return res.status(500).json({
        success: false,
        error: 'Server configuration error',
        message: 'Password reset is not configured.',
      });
    }
    const parts = token.split('.');
    if (parts.length !== 3) {
      return res.status(400).json({
        success: false,
        error: 'Invalid reset link',
        message: 'Invalid or expired reset link. Please request a new password reset.',
      });
    }
    let userId;
    try {
      const b64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
      const padded = b64 + '='.repeat((4 - (b64.length % 4)) % 4);
      const payload = JSON.parse(Buffer.from(padded, 'base64').toString('utf8'));
      userId = payload.sub;
    } catch {
      return res.status(400).json({
        success: false,
        error: 'Invalid reset link',
        message: 'Invalid or expired reset link. Please request a new password reset.',
      });
    }
    if (!userId) {
      return res.status(400).json({
        success: false,
        error: 'Invalid reset link',
        message: 'Invalid or expired reset link. Please request a new password reset.',
      });
    }
    const { createClient } = await import('@supabase/supabase-js');
    const supabaseAdmin = createClient(supabaseUrl, serviceKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { error } = await supabaseAdmin.auth.admin.updateUserById(userId, { password });
    if (error) {
      console.error('[reset-password]', error.message);
      return res.status(400).json({
        success: false,
        error: 'Reset failed',
        message: error.message,
      });
    }
    return res.json({
      success: true,
      message: 'Your password has been reset successfully.',
    });
  } catch (err) {
    console.error('[reset-password] Unexpected:', err?.message || err, err?.stack || '');
    return res.status(500).json({
      success: false,
      error: 'Failed to reset password',
      message: err?.message || 'An error occurred while resetting your password.',
    });
  }
});

// POST /api/auth/change-password - Change password (Supabase Auth)
app.post('/api/auth/change-password', requireAuth, async (req, res) => {
  try {
    const userId = req.userId || req.user?.id;
    if (!userId) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'Both passwords required' });
    }

    if (newPassword.length < 8) {
      return res.status(400).json({ error: 'Password must be 8+ characters' });
    }

    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseAnonKey = process.env.SUPABASE_ANON_KEY;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!supabaseUrl || !supabaseAnonKey || !supabaseServiceKey) {
      return res.status(500).json({ error: 'Server configuration error' });
    }

    const { createClient } = await import('@supabase/supabase-js');
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

    // Get user email from profiles
    const { data: profile, error: profileError } = await supabaseAdmin
      .from('profiles')
      .select('email')
      .eq('id', userId)
      .single();

    if (profileError || !profile?.email) {
      return res.status(400).json({ error: 'Could not find user profile' });
    }

    // Verify current password via Supabase Auth sign-in
    const authClient = createClient(supabaseUrl, supabaseAnonKey, { auth: { persistSession: false } });
    const { error: signInError } = await authClient.auth.signInWithPassword({
      email: profile.email,
      password: currentPassword,
    });

    if (signInError) {
      return res.status(401).json({ error: 'Current password is incorrect' });
    }

    // Update password in Supabase Auth
    const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(userId, {
      password: newPassword,
    });

    if (updateError) {
      console.error('[Change Password] Update error:', updateError);
      return res.status(500).json({ error: 'Failed to change password' });
    }

    return res.status(200).json({ success: true, message: 'Password changed successfully' });
  } catch (err) {
    console.error('[Change Password]', err);
    return res.status(500).json({ error: 'Failed to change password' });
  }
});

// POST /api/auth/link-whatsapp - Link WhatsApp number so web app shows WhatsApp-created projects
app.post('/api/auth/link-whatsapp', requireAuth, async (req, res) => {
  try {
    const userId = req.userId || req.user?.id;
    if (!userId) {
      return res.status(401).json({ success: false, error: 'Not authenticated' });
    }

    const { phone } = req.body;
    if (!phone || typeof phone !== 'string') {
      return res.status(400).json({ success: false, error: 'Phone number is required' });
    }

    const normalized = phone.trim().replace(/\s/g, '');
    const withPlus = normalized.startsWith('+') ? normalized : `+${normalized}`;

    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, error: 'Server not configured' });
    }

    const { createClient } = await import('@supabase/supabase-js');
    const supabase = createClient(supabaseUrl, supabaseServiceKey, { auth: { persistSession: false } });

    const { data, error } = await supabase
      .from('profiles')
      .update({ auth_user_id: userId, updated_at: new Date().toISOString() })
      .eq('whatsapp_number', withPlus)
      .select('id');

    if (error) {
      if ((error.message || '').toLowerCase().includes('auth_user_id')) {
        return res.status(500).json({
          success: false,
          error: 'Linking not available: add column auth_user_id (UUID) to profiles table.',
        });
      }
      console.error('[Link WhatsApp]', error);
      return res.status(500).json({ success: false, error: error.message || 'Update failed' });
    }

    if (!data || data.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'No WhatsApp profile found for this number. Use this exact number in WhatsApp (e.g. +2349165631240).',
      });
    }

    return res.status(200).json({ success: true, message: 'WhatsApp number linked. Your WhatsApp projects will now appear on the web.' });
  } catch (err) {
    console.error('[Link WhatsApp]', err);
    return res.status(500).json({ success: false, error: 'Failed to link WhatsApp' });
  }
});

// POST /api/waitlist - Join waitlist (landing page)
app.post('/api/waitlist', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email || typeof email !== 'string' || !email.trim()) {
      return res.status(400).json({ success: false, error: 'Email is required' });
    }
    const trimmed = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
      return res.status(400).json({ success: false, error: 'Invalid email address' });
    }
    // Optional: persist to DB (e.g. waitlist table) or external service
    console.log('[Waitlist] Joined:', trimmed);
    res.json({ success: true, message: 'Thanks for joining the waitlist!' });
  } catch (error) {
    console.error('[Waitlist] Error:', error);
    res.status(500).json({ success: false, error: 'Could not join waitlist' });
  }
});

// ============================================================================
// PROJECTS ENDPOINTS (always available - BEFORE server app mounts)
// ============================================================================

// GET all projects for current user
app.get('/api/projects', requireAuth, async (req, res) => {
  try {
    const userId = req.userId; // Set by requireAuth middleware
    
    if (!userId) {
      console.log('[Get Projects] No user ID in session');
      return res.status(401).json({ 
        success: false,
        error: 'Not authenticated',
        message: 'Please log in to view projects'
      });
    }

    console.log('[Get Projects] Fetching projects for user:', userId);

    // Initialize Supabase client
    const { createClient } = await import('@supabase/supabase-js');
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error('[Get Projects] Missing Supabase credentials');
      return res.status(500).json({
        success: false,
        error: 'Server configuration error',
        message: 'SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be configured',
      });
    }

    // Create Supabase client with service role key (bypasses RLS)
    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    // Include projects from linked WhatsApp profiles (profiles.auth_user_id = this user)
    let userIdsToFetch = [userId];
    const { data: linkedProfiles, error: linkedError } = await supabase
      .from('profiles')
      .select('id')
      .eq('auth_user_id', userId);
    if (!linkedError && linkedProfiles && Array.isArray(linkedProfiles)) {
      const ids = linkedProfiles.map((p) => p.id).filter(Boolean);
      userIdsToFetch = [...new Set([userId, ...ids])];
    }

    // Fetch projects: owned by user (or linked profiles) OR managed by user
    // NOTE: we intentionally do NOT select the stale `projects.spent` column —
    // spent is always computed live from expenses below so the list can never
    // disagree with reality. See Investigation 1, RC #2.
    const { data: projectsOwned, error: errOwned } = await supabase
      .from('projects')
      .select(`
        id,
        user_id,
        name,
        description,
        budget,
        currency,
        status,
        created_at,
        updated_at
      `)
      .in('user_id', userIdsToFetch)
      .order('created_at', { ascending: false });

    if (errOwned) {
      console.error('[Get Projects] Database error:', errOwned);
      return res.status(500).json({
        success: false,
        error: 'Failed to fetch projects',
        message: errOwned.message,
      });
    }

    const { data: projectsManaged, error: errManaged } = await supabase
      .from('projects')
      .select(`
        id,
        user_id,
        name,
        description,
        budget,
        currency,
        status,
        created_at,
        updated_at
      `)
      .eq('manager_id', userId)
      .order('created_at', { ascending: false });

    if (errManaged) {
      console.error('[Get Projects] Managed projects error:', errManaged);
    }

    const seen = new Set((projectsOwned || []).map((p) => p.id));
    const projects = [...(projectsOwned || [])];
    for (const p of projectsManaged || []) {
      if (!seen.has(p.id)) {
        seen.add(p.id);
        projects.push(p);
      }
    }
    projects.sort((a, b) => new Date((b.updated_at || b.created_at) || 0) - new Date((a.updated_at || a.created_at) || 0));

    console.log('[Get Projects] Successfully fetched', projects?.length || 0, 'projects');

    const projectIds = (projects || []).map((p) => p.id).filter(Boolean);
    let expenseSums = {}; // project_id -> { totalSpent, lastActivity }
    let dailyLogMax = {}; // project_id -> lastLogDate

    if (projectIds.length > 0) {
      // All monetary values are in the project's base currency unit (e.g. UGX
      // shillings). NEVER multiply / divide by 1000 or 1_000_000 here — only
      // for display formatting at the edge.
      const { data: expenseRows } = await supabase
        .from('expenses')
        .select('project_id, amount, created_at, deleted_at')
        .in('project_id', projectIds)
        .is('deleted_at', null);
      if (expenseRows && Array.isArray(expenseRows)) {
        // Accumulate in integer cents to avoid float drift on big totals.
        const centsSums = {};
        for (const row of expenseRows) {
          const pid = row.project_id;
          if (!pid) continue;
          if (!expenseSums[pid]) expenseSums[pid] = { totalSpent: 0, lastActivity: null };
          const amt = parseFloat(row.amount);
          if (Number.isFinite(amt) && amt > 0) {
            centsSums[pid] = (centsSums[pid] || 0) + Math.round(amt * 100);
          }
          const at = row.created_at;
          if (at && (!expenseSums[pid].lastActivity || new Date(at) > new Date(expenseSums[pid].lastActivity))) {
            expenseSums[pid].lastActivity = at;
          }
        }
        for (const pid of Object.keys(centsSums)) {
          expenseSums[pid].totalSpent = centsSums[pid] / 100;
        }
      }
      const { data: logRows } = await supabase
        .from('daily_logs')
        .select('project_id, log_date')
        .in('project_id', projectIds);
      if (logRows && Array.isArray(logRows)) {
        for (const row of logRows) {
          const pid = row.project_id;
          if (!pid || !row.log_date) continue;
          const d = row.log_date.toString().substring(0, 10);
          if (!dailyLogMax[pid] || d > dailyLogMax[pid]) dailyLogMax[pid] = d;
        }
      }
    }

    // Transform to match frontend expectations.
    //
    //   ▸ `spent` is ALWAYS the live sum of non-deleted expense rows. The
    //     stored `projects.spent` column is explicitly ignored because it has
    //     no writer keeping it fresh (see Investigation 1, RC #2).
    //   ▸ `progress` is NOT returned. Previously this field held
    //     `Math.min(100, spent/budget)` masquerading as construction progress
    //     and contradicted the dashboard's `progress.overallPercentage`. Until
    //     the product has a real milestone/tasks-based progress source, the
    //     list endpoint should not invent one.
    const transformedProjects = (projects || []).map(project => {
      const pid = project.id;
      const fromExpenses = expenseSums[pid];
      // Zero (not the stale stored column) when no non-deleted expenses exist.
      const realSpent =
        fromExpenses && Number.isFinite(fromExpenses.totalSpent)
          ? fromExpenses.totalSpent
          : 0;
      const lastExpenseAt = fromExpenses ? fromExpenses.lastActivity : null;
      const lastLogDate = dailyLogMax[pid] || null;
      const projectUpdated = project.updated_at || project.created_at || null;
      const lastActivity = [lastExpenseAt, lastLogDate, projectUpdated]
        .filter(Boolean)
        .map(d => (d.toString().length === 10 ? d + 'T12:00:00Z' : d))
        .reduce((latest, d) => {
          const t = new Date(d).getTime();
          return !latest || t > new Date(latest).getTime() ? d : latest;
        }, null);
      const budgetRaw = parseFloat(project.budget);
      const budget = Number.isFinite(budgetRaw) && budgetRaw > 0 ? budgetRaw : 0;

      return {
        id: project.id,
        userId: project.user_id,
        name: project.name,
        description: project.description,
        budget,
        budgetAmount: budget,
        spent: realSpent,
        totalSpent: realSpent,
        currency: project.currency || 'UGX',
        status: project.status || 'active',
        hasBudget: budget > 0,
        lastActivity: lastActivity || project.updated_at || project.created_at,
        createdAt: project.created_at,
        updatedAt: project.updated_at,
      };
    });

    res.json({
      success: true,
      projects: transformedProjects,
    });
  } catch (error) {
    console.error('[Get Projects] Unexpected error:', error);
    console.error('[Get Projects] Error stack:', error.stack);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch projects',
      details: error.message,
    });
  }
});

// POST create new project
app.post('/api/projects', requireAuth, async (req, res) => {
  try {
    const userId = req.userId; // Set by requireAuth middleware
    const { name, description, budget, budgetAmount, currency = 'UGX', status = 'active' } = req.body;

    // Support both 'budget' and 'budgetAmount' for backward compatibility
    const budgetRaw = budget || budgetAmount;
    function parseBudgetValue(val) {
      if (val == null || val === '') return NaN;
      const s = String(val).replace(/,/g, '').replace(/\s/g, '').trim();
      if (!s) return NaN;
      const mMatch = s.match(/^(\d+(?:\.\d+)?)[Mm]$/);
      const bMatch = s.match(/^(\d+(?:\.\d+)?)[Bb]$/);
      if (mMatch) return parseFloat(mMatch[1]) * 1e6;
      if (bMatch) return parseFloat(bMatch[1]) * 1e9;
      return parseFloat(s);
    }
    const parsedBudget = parseBudgetValue(budgetRaw);

    console.log('[Create Project] ============================================');
    console.log('[Create Project] Request received:', {
      userId,
      name,
      description,
      budget: budgetRaw,
      parsedBudget,
      currency,
      status,
      bodyKeys: Object.keys(req.body),
    });
    console.log('[Create Project] Auth:', {
      userId: req.userId || null,
    });

    // Check authentication
    if (!userId) {
      console.error('[Create Project] ❌ No user ID (JWT required)');
      return res.status(401).json({ 
        success: false,
        error: 'Not authenticated',
        message: 'Please log in to create projects'
      });
    }

    // Validation
    if (!name || typeof name !== 'string' || name.trim() === '') {
      console.error('[Create Project] ❌ Validation failed: name is required');
      return res.status(400).json({
        success: false,
        error: 'Project name is required',
        message: 'Please provide a project name',
      });
    }

    if (!budgetRaw || isNaN(parsedBudget) || parsedBudget <= 0) {
      console.error('[Create Project] ❌ Validation failed: invalid budget');
      return res.status(400).json({
        success: false,
        error: 'Valid budget amount is required',
        message: 'Budget amount must be greater than 0 (e.g. 30000000 or 30M)',
      });
    }

    // Initialize Supabase client
    const { createClient } = await import('@supabase/supabase-js');
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    console.log('[Create Project] Environment check:', {
      hasSupabaseUrl: !!supabaseUrl,
      hasServiceKey: !!supabaseServiceKey,
      urlLength: supabaseUrl?.length || 0,
      keyLength: supabaseServiceKey?.length || 0,
    });

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error('[Create Project] ❌ Missing Supabase credentials');
      return res.status(500).json({
        success: false,
        error: 'Server configuration error',
        message: 'SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be configured',
        debug: {
          hasUrl: !!supabaseUrl,
          hasKey: !!supabaseServiceKey,
        }
      });
    }

    // Create Supabase client with service role key
    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    // Normalize status - new schema uses 'active', 'completed', 'on_hold'
    const validStatuses = ['active', 'completed', 'on_hold'];
    let normalizedStatus = 'active';
    if (status && typeof status === 'string') {
      const lowerStatus = status.toLowerCase().trim();
      // Map old status values to new ones
      if (lowerStatus === 'paused') {
        normalizedStatus = 'on_hold';
      } else if (validStatuses.includes(lowerStatus)) {
        normalizedStatus = lowerStatus;
      }
    }

    // Parse budget amount (already parsed above)
    if (isNaN(parsedBudget) || parsedBudget < 0) {
      console.error('[Create Project] ❌ Invalid budget amount:', budgetRaw);
      return res.status(400).json({
        success: false,
        error: 'Invalid budget amount',
        message: 'Budget must be a valid positive number (e.g. 30M or 30,000,000)',
      });
    }

    // Verify profile exists before creating project (projects reference profiles.id)
    const { data: profileCheck } = await supabase
      .from('profiles')
      .select('id')
      .eq('id', userId)
      .single();

    if (!profileCheck) {
      console.error('[Create Project] ❌ User profile not found:', userId);
          return res.status(400).json({
            success: false,
        error: 'User profile not found',
        message: 'Your profile was not found. Please log out and log in again, or contact support.',
      });
    }
    console.log('[Create Project] ✅ Profile verified');

    // Prepare insert data
    const insertData = {
      user_id: userId,
      name: name.trim(),
      description: description?.trim() || null,
      budget: parsedBudget,
      currency: currency || 'UGX',
      status: normalizedStatus,
      spent: 0, // Will be calculated automatically by trigger
    };

    console.log('[Create Project] Inserting project with data:', insertData);

    // Insert project
    const { data: project, error: insertError } = await supabase
      .from('projects')
      .insert([insertData])
      .select()
      .single();

    if (insertError) {
      console.error('[Create Project] ❌ Database error:', {
        message: insertError.message,
        code: insertError.code,
        details: insertError.details,
        hint: insertError.hint,
        error: insertError,
      });
      
      // Provide more specific error messages
      let errorMessage = insertError.message || 'Failed to create project';
      let statusCode = 500;
      
      if (insertError.code === '23505') { // Unique violation
        errorMessage = 'A project with this name already exists';
        statusCode = 409;
      } else if (insertError.code === '23503') { // Foreign key violation
        errorMessage = 'Invalid user ID - user not found';
        statusCode = 400;
      } else if (insertError.code === '42501') { // Insufficient privilege
        errorMessage = 'Permission denied - check RLS policies';
        statusCode = 403;
      } else if (insertError.message?.includes('column') && insertError.message?.includes('does not exist')) {
        errorMessage = 'Database schema mismatch - column not found. Please run migrations.';
        statusCode = 500;
      }
      
      return res.status(statusCode).json({ 
        success: false,
        error: 'Failed to create project',
        message: errorMessage,
        details: insertError.details || insertError.hint,
        code: insertError.code,
        debug: process.env.NODE_ENV === 'development' ? {
          fullError: insertError,
          insertData,
        } : undefined,
      });
    }

    if (!project) {
      console.error('[Create Project] ❌ No project returned from insert');
      return res.status(500).json({
        success: false,
        error: 'Failed to create project',
        message: 'Project was not created - no data returned',
      });
    }

    console.log('[Create Project] ✅ Successfully created project:', {
      id: project.id,
      name: project.name,
      userId: project.user_id,
    });

    // Transform to match frontend expectations
    const transformedProject = {
      id: project.id,
      userId: project.user_id,
      name: project.name,
      description: project.description,
      budget: parseFloat(project.budget || 0),
      budgetAmount: parseFloat(project.budget || 0), // Keep for backward compatibility
      spent: parseFloat(project.spent || 0),
      currency: project.currency || 'UGX',
      status: project.status || 'active',
      createdAt: project.created_at,
      updatedAt: project.updated_at,
    };

    res.status(201).json({
      success: true,
      project: transformedProject,
      message: 'Project created successfully',
    });
  } catch (error) {
    console.error('[Create Project] ❌ Unexpected error:', {
      message: error.message,
      stack: error.stack,
      name: error.name,
    });
    res.status(500).json({
      success: false,
      error: 'Failed to create project',
      message: error.message || 'An unexpected error occurred',
      details: process.env.NODE_ENV === 'development' ? error.stack : undefined,
    });
  }
});

// GET /api/projects/:projectId/settings
app.get('/api/projects/:projectId/settings', requireAuth, async (req, res) => {
  try {
    const userId = req.userId;
    const { projectId } = req.params;

    if (!userId || !projectId) {
      return res.status(400).json({ success: false, error: 'Missing projectId' });
    }

    const { createClient } = await import('@supabase/supabase-js');
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, error: 'Server configuration error' });
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const { data: project, error: projectError } = await supabase
      .from('projects')
      .select('id, name, description, budget, status, channel_type, created_at')
      .eq('id', projectId)
      .eq('user_id', userId)
      .single();

    if (projectError || !project) {
      return res.status(404).json({ success: false, error: 'Project not found' });
    }

    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('full_name, whatsapp_number, default_currency, preferred_language')
      .eq('id', userId)
      .single();

    const profileData = profileError ? {} : {
      full_name: profile?.full_name || '',
      whatsapp_number: profile?.whatsapp_number || '',
      default_currency: profile?.default_currency || 'UGX',
      preferred_language: profile?.preferred_language || 'en',
    };

    res.json({
      success: true,
      project: {
        id: project.id,
        name: project.name,
        description: project.description || '',
        budget: parseFloat(project.budget || 0),
        status: project.status || 'active',
        channel_type: project.channel_type || 'direct',
        created_at: project.created_at,
      },
      profile: profileData,
    });
  } catch (err) {
    console.error('[Settings GET] Error:', err);
    res.status(500).json({ success: false, error: err.message || 'Failed to load settings' });
  }
});

// PATCH /api/projects/:projectId/settings
app.patch('/api/projects/:projectId/settings', requireAuth, async (req, res) => {
  try {
    const userId = req.userId;
    const { projectId } = req.params;
    const { name, description, budget, status, channel_type, whatsapp_number, full_name } = req.body;

    if (!userId || !projectId) {
      return res.status(400).json({ success: false, error: 'Missing projectId' });
    }

    const { createClient } = await import('@supabase/supabase-js');
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ success: false, error: 'Server configuration error' });
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const { data: existing } = await supabase
      .from('projects')
      .select('id')
      .eq('id', projectId)
      .eq('user_id', userId)
      .single();

    if (!existing) {
      return res.status(404).json({ success: false, error: 'Project not found' });
    }

    const projectUpdates = {};
    if (name !== undefined) projectUpdates.name = String(name).trim();
    if (description !== undefined) projectUpdates.description = description?.trim() || null;
    if (budget !== undefined) {
      const b = parseFloat(budget);
      if (!isNaN(b) && b >= 0) projectUpdates.budget = b;
    }
    if (channel_type !== undefined && ['direct', 'group'].includes(String(channel_type))) {
      projectUpdates.channel_type = channel_type;
    }
    if (status !== undefined && ['active', 'completed', 'on_hold', 'paused'].includes(String(status))) {
      projectUpdates.status = status === 'paused' ? 'on_hold' : status;
    }

    if (Object.keys(projectUpdates).length > 0) {
      const { data: updatedProject, error: updateErr } = await supabase
        .from('projects')
        .update({ ...projectUpdates, updated_at: new Date().toISOString() })
        .eq('id', projectId)
        .eq('user_id', userId)
        .select()
        .single();

      if (updateErr) {
        return res.status(500).json({ success: false, error: updateErr.message || 'Failed to update project' });
      }
    }

    const profileUpdates = {};
    if (whatsapp_number !== undefined) profileUpdates.whatsapp_number = String(whatsapp_number).trim();
    if (full_name !== undefined) profileUpdates.full_name = String(full_name).trim();

    if (Object.keys(profileUpdates).length > 0) {
      const { error: profileErr } = await supabase
        .from('profiles')
        .update({ ...profileUpdates, updated_at: new Date().toISOString() })
        .eq('id', userId);

      if (profileErr) {
        return res.status(500).json({ success: false, error: profileErr.message || 'Failed to update profile' });
      }
    }

    const { data: project } = await supabase
      .from('projects')
      .select('id, name, description, budget, status, channel_type, created_at, updated_at')
      .eq('id', projectId)
      .eq('user_id', userId)
      .single();

    res.json({
      success: true,
      project: project ? {
        id: project.id,
        name: project.name,
        description: project.description || '',
        budget: parseFloat(project.budget || 0),
        status: project.status || 'active',
        channel_type: project.channel_type || 'direct',
        created_at: project.created_at,
      } : null,
    });
  } catch (err) {
    console.error('[Settings PATCH] Error:', err);
    res.status(500).json({ success: false, error: err.message || 'Failed to save settings' });
  }
});

// ============================================================================
// DASHBOARD ENDPOINTS (always available - BEFORE server app mounts)
// ============================================================================

// GET /api/dashboard/summary
app.get('/api/dashboard/summary', requireAuth, async (req, res) => {
  try {
    const userId = req.userId; // Set by requireAuth middleware
    const dbConnection = initializeDatabase();
    
    if (!dbConnection) {
      return res.status(500).json({
        success: false,
        error: 'Database connection not available',
      });
    }

    // Get project ID from query parameter, or use first project
    let activeProjectId = req.query.projectId || req.query.project;
    
    if (!activeProjectId) {
      // Get user's first project if no project ID specified
      const projectsResult = await dbConnection.execute(sql`
        SELECT id FROM projects
        WHERE user_id = ${userId}
        ORDER BY created_at DESC
        LIMIT 1
      `);
      const firstProject = Array.isArray(projectsResult) 
        ? projectsResult[0] 
        : (projectsResult.rows ? projectsResult.rows[0] : projectsResult);
      activeProjectId = firstProject?.id;
    }

    if (!activeProjectId) {
      return res.json({
        success: true,
        summary: {
          overallProgress: 0,
          onTimeStatus: { isDelayed: false, daysDelayed: 0 },
          budgetHealth: { percent: 0, remaining: 0, totalBudget: 0, totalSpent: 0 },
          activeIssues: { total: 0, critical: 0 },
        },
      });
    }

    // Get project details
    const projectResult = await dbConnection.execute(sql`
      SELECT id, name, budget
      FROM projects
      WHERE id = ${activeProjectId} AND (user_id = ${userId} OR manager_id = ${userId})
      LIMIT 1
    `);
    const project = Array.isArray(projectResult) ? projectResult[0] : (projectResult.rows ? projectResult.rows[0] : projectResult);

    // SECURITY: If the project doesn't belong to this user, do NOT fall through
    // to aggregate their expenses/tasks — that would leak cross-tenant data.
    if (!project) {
      return res.status(404).json({
        success: false,
        error: 'Project not found',
      });
    }

    // Get expenses
    const expensesResult = await dbConnection.execute(sql`
      SELECT COALESCE(SUM(CAST(amount AS DECIMAL)), 0) as total
      FROM expenses
      WHERE project_id = ${activeProjectId}
        AND deleted_at IS NULL
    `);
    const totalSpent = parseFloat(Array.isArray(expensesResult) ? expensesResult[0]?.total : (expensesResult.rows ? expensesResult.rows[0]?.total : expensesResult?.total) || '0');

    // Get tasks (non-deleted only)
    const tasksResult = await dbConnection.execute(sql`
      SELECT COUNT(*) as total,
             COUNT(*) FILTER (WHERE status IN ('pending', 'in_progress')) as open,
             COUNT(*) FILTER (WHERE status IN ('pending', 'in_progress') AND priority = 'high') as critical
      FROM tasks
      WHERE project_id = ${activeProjectId}
        AND deleted_at IS NULL
    `);
    const tasks = Array.isArray(tasksResult) ? tasksResult[0] : (tasksResult.rows ? tasksResult.rows[0] : tasksResult);
    const totalTasks = parseInt(tasks?.total || '0');
    const completedTasks = parseInt(tasks?.total || '0') - parseInt(tasks?.open || '0');
    const overallProgress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

    const totalBudget = parseFloat(project?.budget || '0');
    const spentPercent = totalBudget > 0 ? Math.round((totalSpent / totalBudget) * 100) : 0;

    res.json({
      success: true,
      summary: {
        overallProgress,
        onTimeStatus: { isDelayed: false, daysDelayed: 0 },
        budgetHealth: {
          percent: spentPercent,
          remaining: totalBudget - totalSpent,
          totalBudget,
          totalSpent,
        },
        activeIssues: {
          total: parseInt(tasks?.open || '0'),
          critical: parseInt(tasks?.critical || '0'),
        },
        projectName: project?.name || 'Unknown Project',
      },
    });
  } catch (error) {
    console.error('[Dashboard Summary] Error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch dashboard summary',
      details: error.message,
    });
  }
});

// GET /api/dashboard/progress
app.get('/api/dashboard/progress', requireAuth, async (req, res) => {
  try {
    const userId = req.userId; // Set by requireAuth middleware
    const dbConnection = initializeDatabase();
    
    if (!dbConnection) {
      return res.status(500).json({
        success: false,
        error: 'Database connection not available',
      });
    }

    // Get project ID from query parameter, or use first project
    let activeProjectId = req.query.projectId || req.query.project;
    
    if (!activeProjectId) {
      // Get user's first project if no project ID specified
      const projectsResult = await dbConnection.execute(sql`
        SELECT id FROM projects
        WHERE user_id = ${userId}
        ORDER BY created_at DESC
        LIMIT 1
      `);
      const firstProject = Array.isArray(projectsResult) 
        ? projectsResult[0] 
        : (projectsResult.rows ? projectsResult.rows[0] : projectsResult);
      activeProjectId = firstProject?.id;
    }

    if (!activeProjectId) {
      return res.json({
        success: true,
        phases: [],
        upcomingMilestones: [],
      });
    }

    // SECURITY: Check ownership before returning tasks for this project.
    const progressOwnerCheck = await dbConnection.execute(sql`
      SELECT 1 FROM projects
      WHERE id = ${activeProjectId} AND (user_id = ${userId} OR manager_id = ${userId})
      LIMIT 1
    `);
    const progressOwnerRow = Array.isArray(progressOwnerCheck)
      ? progressOwnerCheck[0]
      : (progressOwnerCheck.rows ? progressOwnerCheck.rows[0] : progressOwnerCheck);
    if (!progressOwnerRow) {
      return res.status(404).json({ success: false, error: 'Project not found' });
    }

    // Get tasks for milestones (non-deleted only)
    const tasksResult = await dbConnection.execute(sql`
      SELECT id, title, due_date as "dueDate", priority, status
      FROM tasks
      WHERE project_id = ${activeProjectId}
        AND deleted_at IS NULL
      ORDER BY due_date ASC
      LIMIT 10
    `);
    const tasks = Array.isArray(tasksResult) ? tasksResult : (tasksResult.rows || []);

    // Define phases (simplified - in real app, these would come from database)
    const phases = [
      { id: '1', name: 'Foundation', percentComplete: 100, status: 'completed' },
      { id: '2', name: 'Framing', percentComplete: 75, status: 'in-progress' },
      { id: '3', name: 'Roofing', percentComplete: 50, status: 'in-progress' },
      { id: '4', name: 'Finishing', percentComplete: 20, status: 'in-progress' },
    ];

    // Get upcoming milestones (tasks due in next 7 days)
    const sevenDaysFromNow = new Date();
    sevenDaysFromNow.setDate(sevenDaysFromNow.getDate() + 7);
    
    const upcomingMilestones = tasks
      .filter(task => {
        if (!task.dueDate) return false;
        const dueDate = new Date(task.dueDate);
        return dueDate > new Date() && dueDate <= sevenDaysFromNow;
      })
      .slice(0, 5)
      .map(task => ({
        id: task.id,
        title: task.title || 'Untitled Task',
        dueDate: task.dueDate,
        priority: task.priority || 'medium',
      }));

    res.json({
      success: true,
      phases,
      upcomingMilestones,
    });
  } catch (error) {
    console.error('[Dashboard Progress] Error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch progress data',
      details: error.message,
    });
  }
});

// GET /api/dashboard/budget
app.get('/api/dashboard/budget', requireAuth, async (req, res) => {
  try {
    const userId = req.userId; // Set by requireAuth middleware
    const dbConnection = initializeDatabase();
    
    if (!dbConnection) {
      return res.status(500).json({
        success: false,
        error: 'Database connection not available',
      });
    }

    // Get project ID from query parameter, or use first project
    let activeProjectId = req.query.projectId || req.query.project;
    
    if (!activeProjectId) {
      // Get user's first project if no project ID specified
      const projectsResult = await dbConnection.execute(sql`
        SELECT id FROM projects
        WHERE user_id = ${userId}
        ORDER BY created_at DESC
        LIMIT 1
      `);
      const firstProject = Array.isArray(projectsResult) 
        ? projectsResult[0] 
        : (projectsResult.rows ? projectsResult.rows[0] : projectsResult);
      activeProjectId = firstProject?.id;
    }

    if (!activeProjectId) {
      return res.json({
        success: true,
        breakdown: [],
        vsActual: [],
        cumulativeCosts: [],
        totalBudget: 0,
        spent: 0,
        remaining: 0,
        spentPercent: 0,
      });
    }

    // Get project budget
    const projectResult = await dbConnection.execute(sql`
      SELECT budget
      FROM projects
      WHERE id = ${activeProjectId} AND (user_id = ${userId} OR manager_id = ${userId})
      LIMIT 1
    `);
    const project = Array.isArray(projectResult) ? projectResult[0] : (projectResult.rows ? projectResult.rows[0] : projectResult);

    // SECURITY: Refuse to aggregate another user's expenses if they don't own
    // this project. Previously a stray projectId would return `project=null`
    // but still execute the SUM() below, leaking cross-tenant spend data.
    if (!project) {
      return res.status(404).json({
        success: false,
        error: 'Project not found',
      });
    }

    const totalBudget = parseFloat(project?.budget || '0');

    // Get expenses by category (non-deleted only)
    let expensesResult;
    try {
      expensesResult = await dbConnection.execute(sql`
        SELECT 
          COALESCE(ec.name, 'Uncategorized') as category,
          ec.color as "colorHex",
          COALESCE(SUM(CAST(e.amount AS DECIMAL)), 0) as total
        FROM expenses e
        LEFT JOIN expense_categories ec ON e.category_id = ec.id
        WHERE e.project_id = ${activeProjectId}
          AND e.deleted_at IS NULL
        GROUP BY ec.name, ec.color
        ORDER BY total DESC
      `);
    } catch (dbError) {
      console.error('[Dashboard Budget] Database query error:', dbError);
      // Return empty breakdown if query fails
      expensesResult = [];
    }
    const expenses = Array.isArray(expensesResult) ? expensesResult : (expensesResult?.rows || []);
    
    const totalSpent = expenses.reduce((sum, exp) => sum + parseFloat(exp.total || '0'), 0);

    const breakdown = expenses.map(exp => ({
      category: exp.category || 'Uncategorized',
      amount: parseFloat(exp.total || '0'),
      percentage: totalSpent > 0 ? Math.round((parseFloat(exp.total || '0') / totalSpent) * 100) : 0,
      colorHex: exp.colorHex || '#A0AEC0',
    }));

    const vsActual = breakdown.map(cat => ({
      category: cat.category,
      budgeted: cat.amount * 1.2, // Simplified - assume 20% over budget
      actual: cat.amount,
      variance: 20,
    }));

    // Get cumulative costs over time (non-deleted only)
    let dailyExpensesResult;
    try {
      dailyExpensesResult = await dbConnection.execute(sql`
        SELECT 
          DATE(expense_date) as date,
          SUM(CAST(amount AS DECIMAL)) as daily_total
        FROM expenses
        WHERE project_id = ${activeProjectId}
          AND deleted_at IS NULL
        GROUP BY DATE(expense_date)
        ORDER BY DATE(expense_date) ASC
      `);
    } catch (dbError) {
      console.error('[Dashboard Budget] Daily expenses query error:', dbError);
      dailyExpensesResult = [];
    }
    const dailyExpenses = Array.isArray(dailyExpensesResult) ? dailyExpensesResult : (dailyExpensesResult?.rows || []);
    
    let cumulative = 0;
    const cumulativeCosts = dailyExpenses.map(exp => {
      cumulative += parseFloat(exp.daily_total || '0');
      return {
        date: exp.date,
        amount: cumulative,
      };
    });

    res.json({
      success: true,
      breakdown,
      vsActual,
      cumulativeCosts,
      totalBudget,
      spent: totalSpent,
      remaining: totalBudget - totalSpent,
      spentPercent: totalBudget > 0 ? Math.round((totalSpent / totalBudget) * 100) : 0,
    });
  } catch (error) {
    console.error('[Dashboard Budget] Error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch budget data',
      details: error.message,
    });
  }
});

// GET /api/dashboard/inventory
app.get('/api/dashboard/inventory', requireAuth, async (req, res) => {
  try {
    // Return hardcoded inventory data (no inventory table exists yet)
    const items = [
      { id: '1', name: 'Cement', unit: 'bags', currentStock: 150, totalStock: 500, stockPercent: 30, consumptionVsEstimate: 10 },
      { id: '2', name: 'Sand', unit: 'tons', currentStock: 50, totalStock: 100, stockPercent: 50, consumptionVsEstimate: -5 },
      { id: '3', name: 'Bricks', unit: 'pieces', currentStock: 1000, totalStock: 5000, stockPercent: 20, consumptionVsEstimate: 0 },
      { id: '4', name: 'Steel Bars', unit: 'kg', currentStock: 500, totalStock: 2000, stockPercent: 25, consumptionVsEstimate: 15 },
    ];

    const usage = [
      { material: 'Cement', used: 350, remaining: 150 },
      { material: 'Sand', used: 50, remaining: 50 },
      { material: 'Bricks', used: 4000, remaining: 1000 },
      { material: 'Steel', used: 1500, remaining: 500 },
    ];

    res.json({
      success: true,
      items,
      usage,
    });
  } catch (error) {
    console.error('[Dashboard Inventory] Error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch inventory data',
      details: error.message,
    });
  }
});

// GET /api/dashboard/issues
app.get('/api/dashboard/issues', requireAuth, async (req, res) => {
  try {
    const userId = req.userId; // Set by requireAuth middleware
    const dbConnection = initializeDatabase();
    
    if (!dbConnection) {
      return res.status(500).json({
        success: false,
        error: 'Database connection not available',
      });
    }

    // Get project ID from query parameter, or use first project
    let activeProjectId = req.query.projectId || req.query.project;
    
    if (!activeProjectId) {
      // Get user's first project if no project ID specified
      const projectsResult = await dbConnection.execute(sql`
        SELECT id FROM projects
        WHERE user_id = ${userId}
        ORDER BY created_at DESC
        LIMIT 1
      `);
      const firstProject = Array.isArray(projectsResult) 
        ? projectsResult[0] 
        : (projectsResult.rows ? projectsResult.rows[0] : projectsResult);
      activeProjectId = firstProject?.id;
    }

    if (!activeProjectId) {
      return res.json({
        success: true,
        todo: [],
        inProgress: [],
        resolved: [],
        criticalIssues: 0,
        highIssues: 0,
        openIssues: 0,
        resolvedThisWeek: 0,
        types: [],
      });
    }

    // SECURITY: Verify the caller owns this project before pulling tasks.
    // Otherwise any authenticated user could read another user's issues by
    // passing a guessed projectId.
    const ownerCheckResult = await dbConnection.execute(sql`
      SELECT 1 FROM projects
      WHERE id = ${activeProjectId} AND (user_id = ${userId} OR manager_id = ${userId})
      LIMIT 1
    `);
    const ownerRow = Array.isArray(ownerCheckResult)
      ? ownerCheckResult[0]
      : (ownerCheckResult.rows ? ownerCheckResult.rows[0] : ownerCheckResult);
    if (!ownerRow) {
      return res.status(404).json({ success: false, error: 'Project not found' });
    }

    // Get tasks as issues (non-deleted only)
    const tasksResult = await dbConnection.execute(sql`
      SELECT id, title, description, status, priority, created_at as "createdAt"
      FROM tasks
      WHERE project_id = ${activeProjectId}
        AND deleted_at IS NULL
      ORDER BY created_at DESC
    `);
    const tasks = Array.isArray(tasksResult) ? tasksResult : (tasksResult.rows || []);

    const todo = tasks.filter(t => t.status === 'pending').map(t => ({
      id: t.id,
      title: t.title || 'Untitled',
      description: t.description || '',
      status: 'todo',
      priority: t.priority || 'medium',
      reportedBy: 'System',
      reportedDate: new Date(t.createdAt),
      type: 'General',
    }));

    const inProgress = tasks.filter(t => t.status === 'in_progress').map(t => ({
      id: t.id,
      title: t.title || 'Untitled',
      description: t.description || '',
      status: 'inProgress',
      priority: t.priority || 'medium',
      reportedBy: 'System',
      reportedDate: new Date(t.createdAt),
      type: 'General',
    }));

    const resolved = tasks.filter(t => t.status === 'completed').map(t => ({
      id: t.id,
      title: t.title || 'Untitled',
      description: t.description || '',
      status: 'resolved',
      priority: t.priority || 'medium',
      reportedBy: 'System',
      reportedDate: new Date(t.createdAt),
      type: 'General',
    }));

    const criticalIssues = tasks.filter(t => t.priority === 'high' && t.status !== 'completed').length;
    const highIssues = tasks.filter(t => t.priority === 'medium' && t.status !== 'completed').length;
    const openIssues = todo.length + inProgress.length;

    // Get resolved this week
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    const resolvedThisWeek = resolved.filter(r => new Date(r.reportedDate) >= weekAgo).length;

    const types = [
      { type: 'Design', count: 2, percentage: 25 },
      { type: 'Safety', count: 3, percentage: 37.5 },
      { type: 'Quality', count: 2, percentage: 25 },
      { type: 'Logistics', count: 1, percentage: 12.5 },
    ];

    res.json({
      success: true,
      todo,
      inProgress,
      resolved,
      criticalIssues,
      highIssues,
      openIssues,
      resolvedThisWeek,
      types,
    });
  } catch (error) {
    console.error('[Dashboard Issues] Error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch issues data',
      details: error.message,
    });
  }
});

// GET /api/dashboard/media
app.get('/api/dashboard/media', requireAuth, async (req, res) => {
  try {
    const userId = req.userId; // Set by requireAuth middleware
    const dbConnection = initializeDatabase();
    
    if (!dbConnection) {
      return res.status(500).json({
        success: false,
        error: 'Database connection not available',
      });
    }

    // Get project ID from query parameter, or use first project
    let activeProjectId = req.query.projectId || req.query.project;
    
    if (!activeProjectId) {
      // Get user's first project if no project ID specified
      const projectsResult = await dbConnection.execute(sql`
        SELECT id FROM projects
        WHERE user_id = ${userId}
        ORDER BY created_at DESC
        LIMIT 1
      `);
      const firstProject = Array.isArray(projectsResult) 
        ? projectsResult[0] 
        : (projectsResult.rows ? projectsResult.rows[0] : projectsResult);
      activeProjectId = firstProject?.id;
    }

    if (!activeProjectId) {
      return res.json({
        success: true,
        recentPhotos: [],
        stats: {
          dailyLogsThisWeek: 0,
          siteCondition: 'Good',
        },
      });
    }

    // SECURITY: Verify project ownership before returning images for it.
    const mediaOwnerCheck = await dbConnection.execute(sql`
      SELECT 1 FROM projects
      WHERE id = ${activeProjectId} AND (user_id = ${userId} OR manager_id = ${userId})
      LIMIT 1
    `);
    const mediaOwnerRow = Array.isArray(mediaOwnerCheck)
      ? mediaOwnerCheck[0]
      : (mediaOwnerCheck.rows ? mediaOwnerCheck.rows[0] : mediaOwnerCheck);
    if (!mediaOwnerRow) {
      return res.status(404).json({ success: false, error: 'Project not found' });
    }

    // Get recent photos (non-deleted only)
    let photosResult;
    try {
      photosResult = await dbConnection.execute(sql`
        SELECT id, storage_path as "storagePath", filename, created_at as "createdAt"
        FROM images
        WHERE project_id = ${activeProjectId}
          AND deleted_at IS NULL
        ORDER BY created_at DESC
        LIMIT 10
      `);
    } catch (dbError) {
      console.error('[Dashboard Media] Database query error:', dbError);
      // Return empty photos if query fails
      photosResult = [];
    }
    const photos = Array.isArray(photosResult) ? photosResult : (photosResult?.rows || []);

    const recentPhotos = photos.map(photo => ({
      id: photo.id,
      url: photo.storagePath || '',
      description: photo.filename || 'Site photo',
      date: photo.createdAt,
    }));

    res.json({
      success: true,
      recentPhotos,
      stats: {
        dailyLogsThisWeek: 5,
        siteCondition: 'Good',
      },
    });
  } catch (error) {
    console.error('[Dashboard Media] Error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch media data',
      details: error.message,
    });
  }
});

// GET /api/dashboard/trends
app.get('/api/dashboard/trends', requireAuth, async (req, res) => {
  try {
    // Generate trend data
    const progressTrend = Array.from({ length: 30 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (29 - i));
      return {
        date: date.toISOString().split('T')[0],
        value: 20 + i * 0.8 + Math.random() * 5,
      };
    });

    const costBurnTrend = Array.from({ length: 30 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (29 - i));
      return {
        date: date.toISOString().split('T')[0],
        value: 50000 + Math.random() * 20000,
      };
    });

    const insights = [
      { id: '1', text: 'Top delay cause: Weather (3 days lost)' },
      { id: '2', text: 'Most used material: Cement (450 bags)' },
      { id: '3', text: 'Foundation phase completed ahead of schedule' },
      { id: '4', text: 'Resolution rate: 85% of issues closed' },
    ];

    res.json({
      success: true,
      progressTrend,
      costBurnTrend,
      dailyBurnRate: 125000,
      insights,
    });
  } catch (error) {
    console.error('[Dashboard Trends] Error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch trends data',
      details: error.message,
    });
  }
});

// Images Endpoint (always available - BEFORE server app mounts)
app.get('/api/images', requireAuth, async (req, res) => {
  try {
    const userId = req.userId; // Set by requireAuth middleware
    
    const limit = parseInt(req.query.limit) || 20;
    const offset = parseInt(req.query.offset) || 0;
    const expenseId = req.query.expense_id;
    
    res.json({
      success: true,
      images: [],
      pagination: {
        total: 0,
        limit,
        offset,
        hasMore: false
      },
      message: 'Images endpoint reached (fallback mode - no images available)',
      filters: {
        expenseId: expenseId || null
      }
    });
  } catch (error) {
    console.error('[Images] Error:', error);
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Test Project Creation Setup
app.get('/api/test/project-creation', async (req, res) => {
  if (process.env.NODE_ENV === 'production' && process.env.ENABLE_DEBUG_ENDPOINTS !== '1') {
    return res.status(404).json({ success: false, error: 'Not found' });
  }
  try {
    // Try to extract token if present (optional auth for test endpoint)
    const token = extractToken(req);
    const userId = token ? (verifyToken(token)?.userId || null) : null;
    
    const { createClient } = await import('@supabase/supabase-js');
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    const checks = {
      authenticated: !!userId,
      userId: userId || null,
      hasSupabaseUrl: !!supabaseUrl,
      hasServiceKey: !!supabaseServiceKey,
      supabaseClient: null,
      tableExists: false,
      canInsert: false,
      rlsEnabled: false,
      error: null,
    };

    if (!supabaseUrl || !supabaseServiceKey) {
      return res.json({
        success: false,
        message: 'Missing Supabase credentials',
        checks,
      });
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    checks.supabaseClient = 'initialized';

    // Check if projects table exists and get its structure
    const { data: tableInfo, error: tableError } = await supabase
      .from('projects')
      .select('id')
      .limit(0);

    if (tableError) {
      checks.error = {
        message: tableError.message,
        code: tableError.code,
        details: tableError.details,
        hint: tableError.hint,
      };
      
      // Check if it's an RLS issue
      if (tableError.code === '42501' || tableError.message?.includes('permission')) {
        checks.rlsEnabled = true;
        checks.error.rlsIssue = true;
      }
    } else {
      checks.tableExists = true;
    }

    // Try a test insert (will be rolled back)
    if (userId && checks.tableExists) {
      const testData = {
        user_id: userId,
        name: 'TEST_PROJECT_DELETE_ME',
        description: 'This is a test project - should be deleted',
        budget: 1,
        currency: 'UGX',
        status: 'active',
        spent: 0,
      };

      const { data: testProject, error: insertError } = await supabase
        .from('projects')
        .insert([testData])
        .select()
        .single();

      if (insertError) {
        checks.error = {
          message: insertError.message,
          code: insertError.code,
          details: insertError.details,
          hint: insertError.hint,
        };
      } else {
        checks.canInsert = true;
        
        // Clean up test project
        await supabase
          .from('projects')
          .delete()
          .eq('id', testProject.id);
      }
    }

    res.json({
      success: checks.canInsert && checks.tableExists,
      message: checks.canInsert 
        ? 'Project creation should work!' 
        : 'Project creation may fail - see checks below',
      checks,
      recommendations: !checks.authenticated 
        ? ['User is not authenticated - please log in']
        : !checks.hasSupabaseUrl || !checks.hasServiceKey
        ? ['Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY environment variables']
        : !checks.tableExists
        ? ['Projects table does not exist - run migrations/create-schema.sql']
        : checks.error?.rlsIssue
        ? ['RLS is blocking inserts - check RLS policies in Supabase']
        : !checks.canInsert
        ? [`Cannot insert projects: ${checks.error?.message || 'Unknown error'}`]
        : ['Everything looks good!'],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined,
    });
  }
});

// Test Supabase and Database connection (admin/dev only — requires auth)
app.get('/api/test/supabase', requireAuth, async (req, res) => {
  if (process.env.NODE_ENV === 'production' && process.env.ENABLE_DEBUG_ENDPOINTS !== '1') {
    return res.status(404).json({ success: false, error: 'Not found' });
  }
  try {
    const { createClient } = await import('@supabase/supabase-js');
    const supabaseUrl = process.env.SUPABASE_URL;
    const supabaseKey = process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!supabaseUrl || !supabaseKey) {
      return res.status(500).json({
        status: 'error',
        message: 'Missing Supabase environment variables',
        env: {
          hasUrl: !!supabaseUrl,
          hasKey: !!supabaseKey,
        }
      });
    }

    const supabase = createClient(supabaseUrl, supabaseKey);

    // Test profiles table
    const { data: profiles, error: profilesError } = await supabase
      .from('profiles')
      .select('id, whatsapp_number, full_name')
      .limit(5);

    // Test projects table
    const { data: projects, error: projectsError } = await supabase
      .from('projects')
      .select('id, name, user_id, budget')
      .limit(5);

    // Test expenses table
    const { data: expenses, error: expensesError } = await supabase
      .from('expenses')
      .select('id, description, amount, user_id')
      .limit(5);

    // Test tasks table
    const { data: tasks, error: tasksError } = await supabase
      .from('tasks')
      .select('id, title, status, user_id')
      .limit(5);

    // Test Drizzle database connection
    let drizzleTest = { connected: false, error: null, method: null };
    try {
      // Initialize database connection directly (no need to import from dist/server)
      const dbConnection = initializeDatabase();
      
      if (!dbConnection) {
        throw new Error('Database connection not initialized - DATABASE_URL may be missing');
      }
      
      drizzleTest.method = 'direct_connection';
      await dbConnection.execute(sql`SELECT 1`);
      drizzleTest.connected = true;
    } catch (dbError) {
      drizzleTest.error = dbError.message;
      drizzleTest.stack = process.env.NODE_ENV === 'development' ? dbError.stack : undefined;
    }

    res.json({
      status: 'ok',
      connection: 'successful',
      supabase: {
        url: supabaseUrl.substring(0, 30) + '...',
        hasKey: !!supabaseKey,
      },
      data: {
        profiles: { 
          count: profiles?.length || 0, 
          error: profilesError?.message || null, 
          sample: profiles?.slice(0, 2) || []
        },
        projects: { 
          count: projects?.length || 0, 
          error: projectsError?.message || null, 
          sample: projects?.slice(0, 2) || []
        },
        expenses: { 
          count: expenses?.length || 0, 
          error: expensesError?.message || null, 
          sample: expenses?.slice(0, 2) || []
        },
        tasks: { 
          count: tasks?.length || 0, 
          error: tasksError?.message || null, 
          sample: tasks?.slice(0, 2) || []
        },
      },
      drizzle: drizzleTest,
    });
  } catch (error) {
    console.error('[Test Supabase] Error:', error);
    res.status(500).json({
      status: 'error',
      message: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
});

// ============================================================================
// FALLBACK ROUTES (non-auth debug etc.)
// ============================================================================

  app.get('/api/debug/db', async (req, res) => {
    if (process.env.NODE_ENV === 'production' && process.env.ENABLE_DEBUG_ENDPOINTS !== '1') {
      return res.status(404).json({ success: false, error: 'Not found' });
    }
    res.json({
      status: 'ok',
      message: 'Debug endpoint (fallback mode)',
      database: {
        url: process.env.DATABASE_URL ? 'configured' : 'not configured'
      }
    });
  });

// ============================================================================
// STATIC FILES
// ============================================================================

const publicPath = join(__dirname, '..', 'dist', 'public');
if (fs.existsSync(publicPath)) {
  app.use(express.static(publicPath));
  console.log(`✅ Serving static files from ${publicPath}`);
} else {
  console.warn(`⚠️ Public directory not found at ${publicPath}`);
}

// ============================================================================
// SPA CATCH-ALL
// ============================================================================

// Catch-all route for SPA (GET requests only)
// POST requests should be handled by specific routes above
// Catch-all route for SPA (GET requests only)
// IMPORTANT: This must come AFTER all other routes including server app
app.get('*', (req, res) => {
  // Don't serve index.html for API routes or webhook routes
  // This only affects GET requests, POST requests are handled by routes above
  if (req.path.startsWith('/api') || req.path.startsWith('/webhook')) {
    return res.status(404).json({ error: 'Not found' });
  }
  
  const indexPath = join(publicPath, 'index.html');
  if (fs.existsSync(indexPath)) {
    res.sendFile(indexPath);
  } else {
    res.status(404).send('Not found - index.html missing');
  }
});

// ============================================================================
// ERROR HANDLER
// ============================================================================

app.use((err, req, res, next) => {
  console.error('[Error Handler]', err);
  const status = err.status || err.statusCode || 500;
  const message = err.message || 'Internal Server Error';
  
  res.status(status).json({ 
    success: false,
    error: message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// Export for Vercel
export default app;

