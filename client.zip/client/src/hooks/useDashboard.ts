import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export const DASHBOARD_SUMMARY_QUERY_KEY = "api/projects/summary";

export interface ProjectSummaryResponse {
  success: boolean;
  project: {
    id: string;
    name: string;
    budget_amount: string | null;
    currency?: string;
    status: string;
    created_at: string;
  };
  /** Project currency (UGX / KES / USD…) — use with formatCurrency instead of hardcoding. */
  currency?: string;
  budget: {
    total: number;
    spent: number;
    remaining: number;
    /** 0-100 clamped for progress rings. */
    percentage: number;
    /** True percentage (can exceed 100 when over budget). */
    rawPercent?: number;
    status?: "healthy" | "warning" | "danger" | "over" | "no-budget";
    isOver?: boolean;
    display?: string;
    dailyBurnRate: number;
    weeklyBurnRate: number;
    weeksRemaining: number | null;
    daysRemaining?: number | null;
    daysRemainingDisplay?: string;
    isEarlyEstimate?: boolean;
    disclaimer?: string | null;
    firstExpenseDate?: string | null;
    budgetRunout?: string | null;
    budgetRunoutDisplay?: string | null;
  };
  categoryTotals?: Array<{
    name: string;
    amount: number;
    count: number;
    percent: number;
  }>;
  schedule: {
    status: "On Track" | "At Risk" | "Delayed";
    daysAhead: number;
    daysBehind: number;
  };
  progress: {
    overallPercentage: number;
    phases: Array<{ name: string; percentage: number; status: "completed" | "in-progress" | "not-started" }>;
    milestones: Array<{ id: string; title: string; due_date: string; status: string }>;
  };
  issues: { total: number; critical: number };
  insights: {
    topDelayCause: string | null;
    mostUsedMaterial: string | null;
    recentHighlight: string | null;
    progressTrend: Array<{ date: string; value: number }>;
    dailyCostBurn: Array<{ date: string; amount: number }>;
  };
  expenses: {
    total: number;
    recent: Array<{
      id: string;
      description: string;
      amount: number;
      category: string;
      expense_date: string;
      created_at: string;
    }>;
    byCategory: Array<{ category: string; total: number }>;
  };
  materials: {
    inventory: Array<{ name: string; quantity: number; unit: string }>;
    lowStock: Array<{ name: string; quantity: number; unit: string }>;
  };
  dailyLog: {
    todayActive: boolean;
    workerCount: number;
    recentPhotos: string[];
    streak: number;
  };
  activity: {
    heatmap: Array<{ date: string; active: boolean; workerCount: number }>;
    recentUpdates: Array<{
      log_date: string;
      worker_count: number | null;
      notes: string | null;
      weather_condition: string | null;
    }>;
  };
  summaryHealth?: {
    overallProgress: number;
    onTimeStatus: {
      isDelayed: boolean;
      daysDelayed: number;
      scheduleStatus?: "On Track" | "At Risk" | "Delayed";
      daysAhead?: number;
    };
    budgetHealth: { percent: number; remaining: number };
    activeIssues: { total: number; critical: number };
  };
  budgetSection?: Record<string, unknown>;
  progressSection?: Record<string, unknown>;
  inventorySection?: Record<string, unknown>;
  issuesSection?: Record<string, unknown>;
  mediaSection?: Record<string, unknown>;
  trendsSection?: Record<string, unknown>;
}

async function fetchProjectSummary(projectId: string): Promise<ProjectSummaryResponse> {
  const res = await apiRequest("GET", `/api/projects/${projectId}/summary`);
  const data = await res.json();
  if (!data.success) {
    throw new Error(data.error || "Failed to fetch project summary");
  }
  return data as ProjectSummaryResponse;
}

/**
 * Fetches the full dashboard summary for a project.
 * Refetches every 30 seconds (staleTime: 30000).
 */
export function useProjectSummary(projectId: string | null | undefined) {
  return useQuery({
    queryKey: [DASHBOARD_SUMMARY_QUERY_KEY, projectId],
    queryFn: () => fetchProjectSummary(projectId!),
    staleTime: 0,
    refetchInterval: 30000,
    refetchOnWindowFocus: true,
    enabled: !!projectId,
  });
}

export interface ProjectExpensesResponse {
  success: boolean;
  summary: {
    total: number;
    spent: number;
    remaining: number;
    percentage: number;
    dailyBurnRate: number;
    weeklyBurnRate: number;
    weeksRemaining: number | null;
  };
  byCategory: Array<{
    category: string;
    total: number;
    count: number;
    percentage: number;
  }>;
  byMonth: Array<{ month: string; amount: number }>;
  thisWeekTotal?: number;
  lastWeekTotal?: number;
  recent: Array<{
    id: string;
    description: string;
    amount: number;
    category: string;
    expense_date: string;
    vendor: string | null;
    source: string | null;
    created_at: string;
    disputed: boolean;
  }>;
  /** Full list of expenses (for Budget page category/trend); falls back to recent if omitted */
  expenses?: Array<{
    id: string;
    description: string;
    amount: number;
    category: string;
    expense_date: string;
    vendor: string | null;
    source: string | null;
    created_at: string;
    disputed: boolean;
  }>;
  vendors: Array<{ name: string; total: number; count: number }>;
}

export function useProjectExpenses(projectId: string | null | undefined) {
  return useQuery({
    queryKey: ["project-expenses", projectId],
    queryFn: async (): Promise<ProjectExpensesResponse> => {
      const res = await apiRequest("GET", `/api/projects/${projectId}/expenses`);
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || "Failed to fetch expenses");
      }
      return data as ProjectExpensesResponse;
    },
    enabled: !!projectId,
    staleTime: 30000,
    refetchInterval: 30000,
    refetchOnWindowFocus: true,
  });
}

export interface ProjectMaterialsResponse {
  success: boolean;
  inventory: Array<{
    id: string;
    name: string;
    quantity: number;
    unit: string;
    last_updated: string | null;
    updated_at: string | null;
    unit_cost: number | null;
    total_cost: number | null;
    low_stock_threshold: number;
    last_purchased_at: string | null;
    last_used_at: string | null;
    source: string;
  }>;
  lowStock: Array<{ name: string; quantity: number; unit: string; low_stock_threshold?: number }>;
  usage: Array<{ name: string; used: number; received: number }>;
  summary: {
    totalItems: number;
    lowStockCount: number;
    lastUpdated: string | null;
  };
}

export function useProjectMaterials(projectId: string | null | undefined) {
  return useQuery({
    queryKey: ["materials", projectId],
    queryFn: async (): Promise<ProjectMaterialsResponse> => {
      const res = await apiRequest("GET", `/api/projects/${projectId}/materials`);
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || "Failed to fetch materials");
      }
      return data as ProjectMaterialsResponse;
    },
    enabled: !!projectId,
    staleTime: 0,
    refetchOnWindowFocus: true,
  });
}

export interface MaterialsDailySummaryResponse {
  success: boolean;
  heatmap: Array<{ date: string; active: boolean; entryCount: number }>;
  stats: {
    totalDaysWithMaterials: number;
    currentStreak: number;
    todayLogged: boolean;
    todayEntryCount: number;
  };
}

export interface MaterialsDailyDateResponse {
  success: boolean;
  date: string;
  entries: Array<{
    id: string;
    material_name: string;
    unit: string;
    quantity: number;
    transaction_type: string;
    description: string | null;
    source: string | null;
    created_at: string | null;
  }>;
}

export function useMaterialsDailySummary(projectId: string | null | undefined) {
  return useQuery({
    queryKey: ["materials-daily-summary", projectId],
    queryFn: async (): Promise<MaterialsDailySummaryResponse> => {
      const res = await apiRequest("GET", `/api/projects/${projectId}/materials/daily`);
      const data = await res.json();
      if (!data.success) throw new Error(data.error || "Failed to load materials calendar");
      return data as MaterialsDailySummaryResponse;
    },
    enabled: !!projectId,
    staleTime: 15000,
  });
}

export function useMaterialsForDate(projectId: string | null | undefined, date: string | null) {
  return useQuery({
    queryKey: ["materials-daily-date", projectId, date],
    queryFn: async (): Promise<MaterialsDailyDateResponse> => {
      const res = await apiRequest("GET", `/api/projects/${projectId}/materials/daily?date=${date}`);
      const data = await res.json();
      if (!data.success) throw new Error(data.error || "Failed to load day");
      return data as MaterialsDailyDateResponse;
    },
    enabled: !!projectId && !!date,
    staleTime: 10000,
  });
}

export interface ProjectDailyResponse {
  success: boolean;
  heatmap: Array<{
    date: string;
    active: boolean;
    workerCount: number;
    hasNotes: boolean;
  }>;
  recentLogs: Array<{
    id: string;
    log_date: string;
    worker_count: number | null;
    notes: string | null;
    weather_condition: string | null;
    photo_urls: string[];
    photo_entries?: Array<{ url: string; caption: string | null; tag: string | null }>;
    created_at: string;
  }>;
  stats: {
    totalActiveDays: number;
    currentStreak: number;
    avgWorkerCount: number;
    totalPhotos: number;
    thisWeekActive: number;
  };
  today: {
    active: boolean;
    workerCount: number;
    notes: string;
    photos: string[];
  };
}

export function useProjectDaily(projectId: string | null | undefined) {
  return useQuery({
    queryKey: ["project-daily", projectId],
    queryFn: async (): Promise<ProjectDailyResponse> => {
      const res = await apiRequest("GET", `/api/projects/${projectId}/daily`);
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || "Failed to fetch daily logs");
      }
      return data as ProjectDailyResponse;
    },
    enabled: !!projectId,
    staleTime: 30000,
    refetchInterval: 15000,
    refetchOnWindowFocus: true,
  });
}

export interface ProjectTrendsResponse {
  success: boolean;
  spending: {
    byMonth: Array<{ month: string; amount: number }>;
    byWeek: Array<{ week: string; amount: number }>;
    trend: "increasing" | "decreasing" | "stable";
    projectedCompletion: string | null;
  };
  workers: {
    byDay: Array<{ date: string; count: number }>;
    average: number;
    peak: number;
    trend: "increasing" | "decreasing" | "stable";
  };
  materials: {
    mostUsed: Array<{ name: string; quantity: number; unit: string }>;
    topVendors: Array<{ name: string; total: number }>;
  };
  alerts: Array<{
    type: "price_anomaly" | "low_stock" | "budget_warning" | "inactivity";
    message: string;
    severity: "low" | "medium" | "high";
    date: string;
  }>;
  predictions: {
    estimatedCompletion: string | null;
    budgetRunout: string | null;
    weeklyBurnRate: number;
  };
}

export function useProjectTrends(projectId: string | null | undefined) {
  return useQuery({
    queryKey: ["project-trends", projectId],
    queryFn: async (): Promise<ProjectTrendsResponse> => {
      const res = await apiRequest("GET", `/api/projects/${projectId}/trends`);
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || "Failed to fetch trends");
      }
      return data as ProjectTrendsResponse;
    },
    enabled: !!projectId,
    staleTime: 30000,
    refetchInterval: 30000,
    refetchOnWindowFocus: true,
  });
}

export interface ProjectTask {
  id: string;
  title: string;
  status: string;
  completed_at: string | null;
  created_at?: string;
}

export function useProjectTasks(projectId: string | null | undefined) {
  return useQuery({
    queryKey: ["tasks", projectId],
    queryFn: async (): Promise<ProjectTask[]> => {
      const res = await apiRequest("GET", `/api/projects/${projectId}/tasks`);
      const data = await res.json();
      if (Array.isArray(data)) return data as ProjectTask[];
      return (data?.tasks ?? data?.data ?? []) as ProjectTask[];
    },
    enabled: !!projectId,
    refetchInterval: 30000,
    refetchOnWindowFocus: true,
  });
}
