import { motion } from "framer-motion";
import { Play, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useLanguage } from "@/contexts/LanguageContext";

export default function Features() {
  const { t } = useLanguage();
  return (
    <section id="features" className="py-24 dark:bg-[#0a0a0a] bg-slate-50 relative overflow-hidden">
      <div className="container mx-auto px-4 max-w-6xl relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-bold dark:text-white text-slate-900 mb-6 leading-tight whitespace-pre-line">
            {t("landing.features.title")}
          </h2>
          <p className="text-lg dark:text-zinc-400 text-slate-500 max-w-3xl mx-auto leading-relaxed">
            {t("landing.features.subtitle")}
          </p>
        </motion.div>

        {/* Features Grid - 2 rows layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          
          {/* Main Feature Card - GREEN GRADIENT with Video (Top Left - spans full width on mobile, half on desktop) */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="bg-gradient-to-br from-[#0f766e] to-[#22c55e] rounded-3xl p-8 relative overflow-hidden"
          >
            <div className="flex flex-col h-full justify-between">
              <div>
                <Link href="/signup">
                  <Button 
                    className="bg-black/20 hover:bg-black/30 text-white border-0 rounded-full px-6 text-sm backdrop-blur-sm mb-6"
                  >
                    {t("landing.features.learnMore")}
                  </Button>
                </Link>
                
                <h3 className="text-3xl lg:text-4xl font-bold text-white leading-tight mb-4">
                  {t("landing.features.manageProjects")}
                </h3>
                
                <p className="text-white/85 leading-relaxed text-sm max-w-md">
                  {t("landing.features.manageProjectsDesc")}
                </p>
              </div>
            </div>
          </motion.div>

          {/* Video Card (Top Right) */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="relative rounded-3xl overflow-hidden dark:bg-zinc-900 bg-slate-200 aspect-[4/3] md:aspect-auto"
          >
            <img
              src="/assets/images/construction-team.jpg"
              alt="Construction team collaboration"
              className="w-full h-full object-cover"
            />
            {/* Play Button - links to demo */}
            <Link href="/demo" className="absolute inset-0 flex items-center justify-center">
              <span className="w-16 h-16 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-2xl transition-all hover:scale-110 cursor-pointer">
                <Play className="w-6 h-6 text-zinc-900 ml-1" fill="currentColor" />
              </span>
            </Link>
          </motion.div>
        </div>

        {/* Bottom Row - 3 Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Built for Real-World Construction */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="dark:bg-[#1a1a1a] bg-white rounded-3xl p-6 dark:border-zinc-800/50 border-slate-200 border"
          >
            {/* Notification Badge */}
            <div className="inline-flex items-center gap-3 dark:bg-zinc-800/80 bg-slate-100 rounded-full px-4 py-3 mb-8">
              <div className="w-8 h-8 rounded-full bg-[#14b8a6] flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-xs dark:text-white text-slate-800 font-medium">{t("landing.features.budgetUpdated")}</p>
                <p className="text-[10px] dark:text-zinc-500 text-slate-500">Today, 10:31am</p>
              </div>
            </div>
            
            <h4 className="text-lg font-semibold dark:text-white text-slate-900 mb-3">
              {t("landing.features.builtForReal")}
            </h4>
            <p className="dark:text-zinc-400 text-slate-600 text-sm leading-relaxed">
              {t("landing.features.builtForRealDesc")}
            </p>
          </motion.div>

          {/* Full Financial Visibility */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="dark:bg-[#1a1a1a] bg-white rounded-3xl p-6 dark:border-zinc-800/50 border-slate-200 border"
          >
            {/* Mini Chart */}
            <div className="mb-6 dark:bg-zinc-800/50 bg-slate-100 rounded-xl p-4">
              <p className="text-xs dark:text-zinc-400 text-slate-600 mb-3">Running Projects</p>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] dark:text-zinc-500 text-slate-500 w-14">Project A</span>
                  <div className="flex-1 h-1.5 dark:bg-zinc-700 bg-slate-200 rounded-full overflow-hidden">
                    <div className="h-full w-[75%] bg-gradient-to-r from-[#14b8a6] to-[#22c55e] rounded-full" />
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] dark:text-zinc-500 text-slate-500 w-14">Project B</span>
                  <div className="flex-1 h-1.5 dark:bg-zinc-700 bg-slate-200 rounded-full overflow-hidden">
                    <div className="h-full w-[60%] bg-gradient-to-r from-[#14b8a6] to-[#22c55e] rounded-full" />
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] dark:text-zinc-500 text-slate-500 w-14">Project C</span>
                  <div className="flex-1 h-1.5 dark:bg-zinc-700 bg-slate-200 rounded-full overflow-hidden">
                    <div className="h-full w-[90%] bg-gradient-to-r from-[#14b8a6] to-[#22c55e] rounded-full" />
                  </div>
                </div>
              </div>
            </div>

            <h4 className="text-lg font-semibold dark:text-white text-slate-900 mb-3">
              {t("landing.features.fullVisibility")}
            </h4>
            <p className="dark:text-zinc-400 text-slate-600 text-sm leading-relaxed">
              {t("landing.features.fullVisibilityDesc")}
            </p>
          </motion.div>

          {/* Right Column - Two stacked cards */}
          <div className="flex flex-col gap-6">
            {/* Users Map Card */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.25 }}
              className="dark:bg-[#1a1a1a] bg-white rounded-3xl p-6 border dark:border-zinc-800/50 border-slate-200 flex-1"
            >
              <div className="flex items-center gap-2 mb-3">
                <div className="flex -space-x-2">
                  <img src="/assets/images/avatar-1.jpg" alt="User" className="w-8 h-8 rounded-full border-2 dark:border-[#1a1a1a] border-white object-cover" />
                  <img src="/assets/images/avatar-2.jpg" alt="User" className="w-8 h-8 rounded-full border-2 dark:border-[#1a1a1a] border-white object-cover" />
                  <img src="/assets/images/avatar-3.jpg" alt="User" className="w-8 h-8 rounded-full border-2 dark:border-[#1a1a1a] border-white object-cover" />
                  <img src="/assets/images/avatar-4.jpg" alt="User" className="w-8 h-8 rounded-full border-2 dark:border-[#1a1a1a] border-white object-cover" />
                </div>
              </div>
              <p className="dark:text-zinc-400 text-slate-600 text-sm leading-relaxed">
                {t("landing.features.usersSpan")}
              </p>
            </motion.div>

            {/* Actionable Project Insights - GREEN */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.35 }}
              className="bg-gradient-to-br from-[#14b8a6] to-[#22c55e] rounded-3xl p-6 relative overflow-hidden flex-1"
            >
              <h4 className="text-lg font-semibold text-white mb-3">
                {t("landing.features.actionableInsights")}
              </h4>
              <p className="text-white/90 text-sm leading-relaxed">
                {t("landing.features.actionableInsightsDesc")}
              </p>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}