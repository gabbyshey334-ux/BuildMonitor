import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

export default function HowItWorks() {
  const { t } = useLanguage();
  const steps = [
    {
      step: "1",
      titleKey: "landing.howitworks.step1",
      descKey: "landing.howitworks.desc1",
      image: "/assets/images/step1-chat.png",
      chatPreview: {
        messages: [
          { type: "incoming", text: "Bought 20 bags of cement", time: "10:30 AM" },
          { type: "incoming", text: "Cost: UGX 180,000", time: "10:31 AM" }
        ]
      }
    },
    {
      step: "2",
      titleKey: "landing.howitworks.step2",
      descKey: "landing.howitworks.desc2",
      image: "/assets/images/step2-update.png",
      notification: {
        icon: <CheckCircle2 className="w-5 h-5 text-[#22c55e]" />,
        titleKey: "landing.features.budgetUpdated",
        subtitle: "Today, 10:31am"
      }
    },
    {
      step: "3",
      titleKey: "landing.howitworks.step3",
      descKey: "landing.howitworks.desc3",
      image: "/assets/images/step3-insights.png",
      chartPreview: {
        title: "KDF Apartments Ntungi",
        progress: 75,
        status: "On Track • Month: January"
      }
    }
  ];

  return (
    <section id="how-it-works" className="py-24 dark:bg-[#0a0a0a] bg-slate-50">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Section Header */}
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-3xl lg:text-4xl font-bold dark:text-white text-slate-900 text-center mb-16"
        >
          {t("landing.howitworks.title")}
        </motion.h2>

        {/* Steps Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="dark:bg-[#111111] bg-white rounded-2xl dark:border-zinc-800/50 border-slate-200 border overflow-hidden hover:border-zinc-700/50 hover:border-slate-300 transition-colors"
            >
              {/* Image/Preview Area */}
              <div className="h-48 dark:bg-zinc-900/50 bg-slate-100 relative p-4 flex items-center justify-center">
                {index === 0 && (
                  /* Chat Preview for Step 1 */
                  <div className="w-full max-w-[240px] dark:bg-[#1a1a1a] bg-white rounded-xl p-3 space-y-2 shadow-xl border dark:border-transparent border-slate-200">
                    <div className="flex items-center gap-2 pb-2 border-b dark:border-zinc-800 border-slate-200">
                      <div className="w-6 h-6 rounded-full bg-[#22c55e]" />
                      <span className="text-xs dark:text-zinc-400 text-slate-500">Site Manager</span>
                    </div>
                    {step.chatPreview.messages.map((msg, i) => (
                      <div key={i} className="bg-[#22c55e]/20 rounded-lg p-2 rounded-tl-none">
                        <p className="text-xs dark:text-white text-slate-800">{msg.text}</p>
                        <span className="text-[10px] dark:text-zinc-500 text-slate-500">{msg.time}</span>
                      </div>
                    ))}
                  </div>
                )}

                {index === 1 && (
                  /* Notification for Step 2 */
                  <div className="w-full max-w-[240px] dark:bg-[#1a1a1a] bg-white rounded-xl p-4 shadow-xl border dark:border-zinc-800 border-slate-200">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#22c55e]/20 flex items-center justify-center">
                        {step.notification.icon}
                      </div>
                      <div>
                        <p className="text-sm font-medium dark:text-white text-slate-800">{step.notification?.titleKey ? t(step.notification.titleKey) : ""}</p>
                        <p className="text-xs dark:text-zinc-500 text-slate-500">{step.notification?.subtitle}</p>
                      </div>
                    </div>
                  </div>
                )}

                {index === 2 && (
                  /* Chart Preview for Step 3 */
                  <div className="w-full max-w-[240px] dark:bg-[#1a1a1a] bg-white rounded-xl p-3 shadow-xl border dark:border-zinc-800 border-slate-200">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <p className="text-xs font-medium text-[#22c55e]">{step.chartPreview.title}</p>
                        <p className="text-[10px] dark:text-zinc-500 text-slate-500">{step.chartPreview.status}</p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] dark:text-zinc-400 text-slate-500 w-12">Progress</span>
                        <div className="flex-1 h-2 dark:bg-zinc-800 bg-slate-200 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-[#14b8a6] to-[#22c55e] rounded-full"
                            style={{ width: `${step.chartPreview.progress}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <span className="w-8 h-8 rounded-full bg-gradient-to-r from-[#22c55e] to-[#14b8a6] flex items-center justify-center text-sm font-bold text-white">
                    {step.step}
                  </span>
                  <h3 className="text-lg font-semibold dark:text-white text-slate-900">{t(step.titleKey)}</h3>
                </div>
                <p className="dark:text-zinc-400 text-slate-600 text-sm leading-relaxed">
                  {t(step.descKey)}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}